class Address extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			infoCompleted:false,
			addressDetail:'',
			checkOneSelected:false,
			checkTwoSelected:false,
		};
		this.handleLivingAddressChange=this.handleLivingAddressChange.bind(this);
		this.handleCheckOneSelectedChange=this.handleCheckOneSelectedChange.bind(this);
		this.handleCheckTwoSelectedChange=this.handleCheckTwoSelectedChange.bind(this);
	}
	componentDidMount(){
		myMap();
	}
	componentWillReceiveProps(nextProps){

		if(nextProps.infoCompleted!==this.props.infoCompleted)
        {    

            this.setState({infoCompleted:nextProps.infoCompleted});
            var target = $('#address');
            
            if(nextProps.infoCompleted)
            {
            	target.css("display", "block");
            	if( target.length ) {
	              $('html, body').stop().animate({
	                  scrollTop: target.offset().top
	              }, 1000);
	            }
            }
            else{
            	target.css("display", "none");

            }
        }
 	}
 	handleLivingAddressChange(event){
 		
		this.setState({addressDetail:event.target.value},()=>{
			this.props.livingAddressCallback(this.state.addressDetail);
		});
	  	//this.setState({isMapSelected:true});//submit button enabled
	}
	handleCheckOneSelectedChange(event){

    	this.setState({checkOneSelected:event.target.checked},()=>{
    		if(this.state.checkOneSelected && this.state.checkTwoSelected)
			{

				this.props.continueEnabledCallback(true);
			}
			else
			{
				this.props.continueEnabledCallback(false);
			}
    	});
    	

    }
    handleCheckTwoSelectedChange(event){

    	this.setState({checkTwoSelected:event.target.checked},()=>{
    		if(this.state.checkOneSelected && this.state.checkTwoSelected)
			{
				//console.log("continueEnabled ");
				this.props.continueEnabledCallback(true);
			}
			else
			{
				this.props.continueEnabledCallback(false);
			}
    	});
    	
    	
    }
	render () {
		return (
			<div id="address" style={{display: 'none'}}>
				<div className="row" style={{marginTop: '3%'}}>
					
					<div className="col-sm-6">
						<input type="text" id="latt" name="latitude" style={{display:'none'}} value=''/>
			            <input type="text" id="long" name="longitude" style={{display:'none'}} value=''/>
						<label htmlFor="work_map">
						محل کار شما:
						</label>
						<input  type="text" className="form-control" id="working_address" 
						placeholder="نام منطقه را وارد کنید" required autoComplete="on" />
						<br />

						<div id="work_map" style={{width: '100%', height: '400px', position: 'relative', overflow: 'hidden'}}></div>

						<br />

					</div>
					<div className="col-sm-6">

						<label htmlFor="postal_address"></label>
						<textarea 
						className="form-control" 
						type="text" 
						id="living_address" 
						required
						onChange={this.handleLivingAddressChange}
						value={this.state.addressDetail}
						data-parsley-trigger="keyup" 
						
						placeholder="لطفا آدرس دقیق پستی محل زندگی تان را بنویسید:" 
						
						  ></textarea>

					</div>
					
				</div>
				<div className="row" style={{marginTop: '1%'}}>
					<div className="col-sm-6">
							
							<div className="form-group" style={{marginTop: '30px'}}>
								<div className="checkbox-control">
									<input 
									type="checkbox" 
									id="check1" 
									value="انتخاب توافق" 
									checked={this.state.checkOneSelected}
									onChange={this.handleCheckOneSelectedChange} 
									/>
									<label htmlFor="check1">
									{'من ' 	}
									<a id="checkout" href="https://kadro.co/terms/" target="_blank">
									 شرایط و مقررات 
									</a>
									{' کادرو را خوانده و پذیرفته ام.'}
									
									</label>
								</div>
								<div className="checkbox-control">
									<input 
									type="checkbox" 
									id="check2" 
									value="قوانین" 
								
									checked={this.state.checkTwoSelected}
									onChange={this.handleCheckTwoSelectedChange}
									 />
									<label htmlFor="check2">
									من تصدیق می کنم تمامی اطلاعات وارد شده مربوط به اینجانب می باشد.
									</label>
								</div>
							</div>
							
						</div>
				</div>		
			</div>
				
			);

		
	}
}