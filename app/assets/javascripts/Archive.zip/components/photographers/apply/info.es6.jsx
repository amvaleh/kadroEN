class Info extends React.Component {
	constructor() {
		super();
		this.state = {
			error_messages:{},
			infoCompleted:false,
			continueEnabled:true,
			emailAddress:'',
			lastName:'',
			mobileNumber:'',
			staticNumber:'',
			firstName:'',
			password:'',
			idealHours:'',
			parentId:'',
			token:'',
			photogapherId:'',
			livingAddress:'',
			workingLat:-1,
			workingLng:-1,
			livingInput:'',
			workingInput:'',
			workingLocation:'',
		};
		
		this.handleEmailChange = this.handleEmailChange.bind(this);
		this.handleLastNameChange = this.handleLastNameChange.bind(this);
        this.handleMobileNumberChange = this.handleMobileNumberChange.bind(this);
        this.handleFirstNameChange = this.handleFirstNameChange.bind(this);
        this.handleStaticNumberChange= this.handleStaticNumberChange.bind(this);
        this.handlePasswordChange= this.handlePasswordChange.bind(this);
        this.handleIdealHoursChange= this.handleIdealHoursChange.bind(this);
        this.handleParentIdChange= this.handleParentIdChange.bind(this);
        this.chunkArrayBySize=this.chunkArrayBySize.bind(this);
    	this.handleSubmitButton = this.handleSubmitButton.bind(this);
        this.handleInformationValidation=this.handleInformationValidation.bind(this);
        this.callPhotographersApi=this.callPhotographersApi.bind(this);
        this.callLocationsApi=this.callLocationsApi.bind(this);
    }
    handleEmailChange(event){
        this.setState({emailAddress: event.target.value});
        this.setState({infoCompleted: false});

    }
    handleLastNameChange(event){
        this.setState({lastName: event.target.value});
        $('#last_name').parsley().validate();
        this.setState({infoCompleted: false});
        this.setState({continueEnabled:true});
    }
    handleMobileNumberChange(event){
        this.setState({mobileNumber: event.target.value});
        this.setState({infoCompleted: false});
        this.setState({continueEnabled:true});
    }
    handleFirstNameChange(event){
        this.setState({firstName: event.target.value});
        $('#first_name').parsley().validate();
        this.setState({infoCompleted: false});
        this.setState({continueEnabled:true});

    }
    handleStaticNumberChange(event){
    	this.setState({staticNumber: event.target.value});
        this.setState({infoCompleted: false});
        this.setState({continueEnabled:true});
    }
    handlePasswordChange(event){
    	this.setState({password: event.target.value});
        this.setState({infoCompleted: false});
        this.setState({continueEnabled:true});
    }
    handleIdealHoursChange(event){
    	this.setState({idealHours: event.target.value});
        this.setState({infoCompleted: false});
        this.setState({continueEnabled:true});
    }
    handleParentIdChange(event){
    	this.setState({parentId: event.target.value});
        this.setState({infoCompleted: false});
        this.setState({continueEnabled:true});
    }
	handleInformationValidation(){

        $('#last_name').parsley().validate();
		$('#first_name').parsley().validate();
		$('#password').parsley().validate();
		$('#ideal_hours').parsley().validate();
        

        $('#mobile_number').parsley().validate();
        $('#static_number').parsley().validate();
        $('#email').parsley().validate();
        if(
        	!$('#first_name').parsley().isValid() ||
			!$('#last_name').parsley().isValid() || 
        	!$('#mobile_number').parsley().isValid() || 
        	!$('#static_number').parsley().isValid()|| 
        	!$('#email').parsley().isValid()||
        	!$('#password').parsley().isValid()||
        	!$('#ideal_hours').parsley().isValid()
        )
        {
            formIsValid = false;
        }
        else{
           formIsValid = true; 
        }
		
      	return formIsValid;
    }
	handleSubmitButton(){
		
		if(!this.state.infoCompleted )	
		{
		
			if(this.handleInformationValidation())
			{
				
				this.callPhotographersApi();
			}
			
		}
		else{

			$('#working_address').parsley().validate();
			$('#check1').parsley().validate();
			$('#check2').parsley().validate();
			if($('#working_address').parsley().isValid()&& $('#check1').parsley().isValid() && $('#check2').parsley().isValid())
			{
				
				this.callLocationsApi();
				
				

				this.props.nextStep();
				
			}
		}
		
	}
	callLocationsApi(){
		let lenzEquipments=[];
		let cameraEquipments=[];
		let kitEquipments=[];
		let data={
			location:{
				living_address:this.state.livingAddress,
				living_long:this.state.workingLng,
				living_lat:this.state.workingLat,
				working_long:this.state.workingLng,
				working_lat:this.state.workingLat,
				living_input:this.state.workingLocation,
				working_input:this.state.workingLocation, 
				photographer_id:this.state.photogapherId
			}
		};
		let body = JSON.stringify(data);
        let url=this.props.link+'/api/v1/locations';
        //console.log(url);
        //console.log(body);
        return fetch(url, {method:'post',
            body: body,
            headers: { "Content-Type": "application/json","Accept":"application/json"  ,"Authorization":this.state.token }})
            .then((response)=>{
            	//console.log(response);
            	//console.log(response.status);
            	if (parseInt(response.status) !== 200) {

            		response.json().then((object) =>{
            			//console.log("response errors:");
            			//console.log(object.errors);
    
                		//move up
                		
    				});
            	}
                else{
                	
                	response.json().then((object) =>{
                		//console.log(object);
                		
						object['data'].map((item) =>{                			
	                		if(item.type=="lenz")
            				{

            					lenzEquipments.push(item);
            				}
            				else if(item.type=="kit")
            				{
            					kitEquipments.push(item);
            				}
            				else{
            					cameraEquipments.push(item);
            				}
            			});
						var data = {}
						data['token']=this.state.token;
		        		data['photographerId']=this.state.photogapherId;
		        		//preparing for sending info component information to other components
		        		let kitChunkedEquipments=[];
		        		kitChunkedEquipments=this.chunkArrayBySize(kitEquipments,2);
		        		this.props.kitEquipmentCallBack(kitChunkedEquipments);
		        		this.props.lenzEquipmentCallBack(lenzEquipments);
		        		this.props.cameraEquipmentCallBack(cameraEquipments);
		        		this.props.infoComponentFieldValues(data);

    				});
                    
                }
            
            	
            })
            .catch(function(e){console.log(e)});

	}
	callPhotographersApi(){
		let error_messages={};
		
		{/*let data={
			photographer:{
				first_name:"پیمان",
				last_name:"زینلی",
				mobile_number:"07446323358",
				email:"peydsa@gmail.com",
				static_number:"0215570983",
				password:"12332134",
				ideal_hours:"20" , 
				parent_id:"kimiasb"
			}
		};*/}
		
		let data={
			photographer:{
				first_name:this.state.firstName,
				last_name:this.state.lastName,
				mobile_number:this.state.mobileNumber,
				email:this.state.emailAddress,
				static_number:this.state.staticNumber,
				password:this.state.password,
				ideal_hours:this.state.idealHours , 
				parent_id:this.state.parentId
			}
		};
		let body = JSON.stringify(data);
        let url=this.props.link+'/api/v1/photographers';
        //console.log(body);
        return fetch(url, {method:'post',
            body: body,
            headers: { "Content-Type": "application/json","Accept":"application/json" }})
            .then((response)=>{
            	//console.log("response photographers: ");
            	//console.log(response);
            	//console.log(response.status);
            	if (parseInt(response.status) !== 200) {

            		response.json().then((object) =>{
            			//console.log("response errors:");
            			//console.log(object.errors);
                		error_messages["email"] = object.errors.email;
                		error_messages["mobile_number"] = object.errors.mobile_number;
                		this.setState({error_messages: error_messages}); 
                		//move up
                		$("html, body").animate({ scrollTop: 0 }, "slow");

                		$('#submitInfoError').css('display', 'block');
    				});
            	}
                else{
					this.setState({infoCompleted:true});
					this.setState({continueEnabled:false});
            		$('#submitInfoError').css('display', 'none');
                	response.json().then((object) =>{
                		
                		this.setState({infoCompleted: true});
                		this.setState({token:object.photographer.token});
                		this.setState({photogapherId:object.photographer.id});
                        //console.log(object.photographer.token);		
                        //console.log(object.photographer.id);	
    				});
                    
                }
     
            	
            	
            })
            .catch(function(e){console.log(e)});
	}
	componentDidMount(){
		$('[data-toggle="why_static_number"]').tooltip({
			title: "کادرو برای احراز هویت عکاسان با شماره ثابتی که می دهند تماس می گیرد و مصاحبه تلفنی کوتاهی از این طریق انجام می دهد."
	    });
	    $('[data-toggle="why_mobile_number"]').tooltip({
			title: "کادرو پروژه های جدید عکاسی را از طریق پیامک به شما اطلاع می دهد و یا در صورت وجود مشکل یا تغییری در برنامه به شما زنگ می زند."
	    });
		$("#latt").on("change", (changeEvt)=> {
			this.setState({workingLat:parseFloat(changeEvt.target.value)});
				
		});
		$("#long").on("change", (changeEvt)=> {
			
	  		this.setState({workingLng:parseFloat(changeEvt.target.value)});
		});
		$("#working_address").on("change", (changeEvt)=> {
	
	  		this.setState({workingLocation:changeEvt.target.value});
		});
	}
	
	chunkArrayBySize(arr,size){
		let chunks = [];
		while (arr.length > 0)
			    chunks.push(arr.splice(0, size));

		return chunks;
	}
	render () {
		return (
			<React.Fragment>
				<section id="main">
					<div className="container">
						<div className="main">
							<div className="tracker">
								<div className="process-tabs-line w-hidden-tiny">
									<span className="step-line step-line-package" style={{width: "33.3333%" ,right: "0%"}}></span>
									<span className="step-line step-line-datetime" style={{width: '33.3333%', right: '33.3333%'}}></span>
									<span className="step-line step-line-details" style={{width: '33.3333%' , right: '66.6667%'}}></span>
								</div>
								<div className="process-tab-button tracker-circle selected" style={{right: '0%'}}>
									<div className="tracker-text">
									اطلاعات اولیه
									</div>
								</div>
								<div className="process-tab-button tracker-circle " style={{right: '33.3333%'}}>
									<div className="tracker-text">
									تجهیزات عکاسی
									</div>
								</div>
								<div className="process-tab-button tracker-circle" style={{right: '66.6667%'}}>
									<div className="tracker-text">
									نمونه کارها
									</div>
								</div>
								<div className="process-tab-button tracker-circle" style={{right: '100%'}}>
									<div className="tracker-text">
									تجربه کاری
									</div>
								</div>
							</div>
							<div className="wrapper">
								<div className="row" style={{marginBottom: '30px'}}>
									<div className="col-sm-6">
										<div className="col-sm-12" style={{marginTop: '5%'}}>
											<div className="text-right text-muted">
												برای راحتی کار با مرورگر دسکتاپ شروع کنید.
											</div>
											<p>{this.state.haveMobileError}</p>
											<p>{this.state.haveEmailError}</p>
											<div className="alert alert-danger" id="submitInfoError" style={{ display: "none"}}>
												<p style={{ color: "red" ,textDecoration: 'none' }}>{this.state.error_messages["mobile_number"]}</p>
  												<p style={{ color: "red" ,textDecoration: 'none' }}>{this.state.error_messages["email"]}</p>
  												<a href={(this.props.link)+"/photographers/sign_in"}>از اینجا می توانید وارد شوید</a>
											</div>
											<label htmlFor="name"></label>
											{/*-- trying to run parsley on form submition #*/}
											<input className="form-control mytextbox" required type="text" id="first_name" placeholder="نام شما" 
											value={this.state.firstName} onChange={this.handleFirstNameChange} data-parsley-pattern="^[آ-ی\s]*$" data-parsley-pattern-message="این مقدار باید فارسی باشد"/>
											{/*#= f.text_field :first_name , placeholder: "نام شما" , className: "form-control" , name: "name" , id: "name", :requried => "" */}
										</div>
										<div className="col-sm-12" style={{marginTop: '5%'}}>
											<label htmlFor="name"></label>
											<input className="form-control mytextbox" required type="text" id="last_name"  placeholder="نام خانوادگی تون "  
											value={this.state.lastName} onChange={this.handleLastNameChange} data-parsley-pattern="^[آ-ی\s]*$" data-parsley-pattern-message="این مقدار باید فارسی باشد"/>
										</div>
										<div className="col-sm-12" style={{marginTop: '5%'}}>
											<label htmlFor="mobile_number"></label>
											<input className="form-control" required type="number" style={{direction: 'ltr', textAlign: 'right'}} name="photographer[mobile_number]" id="mobile_number" placeholder="شماره موبایل تون"  
											value={this.state.mobileNumber} onChange={this.handleMobileNumberChange} data-parsley-type="digits" data-parsley-pattern="(0|\+98)?([ ]|,|-|[()]){0,2}9[0|1|2|3|4|9]([ ]|,|-|[()]){0,2}(?:[0-9]([ ]|,|-|[()]){0,2}){8}" />
										</div>
										<div className="text-center col-sm-12" style={{marginTop: '5px',marginBottom: '5px'}}>
											<span data-html="true" className="text-muted" style={{fontSize: '11px',fontStyle: 'italic'}} data-toggle="why_mobile_number" data-placement="top" >
												<img src="/img/information.png" alt="" style={{width: '30px'}} />
												چرا شماره موبایل نیاز است؟
											</span>
										</div>
										<div className="col-sm-12" style={{marginTop: '5%'}}>
											<input className="form-control" required  id="static_number" placeholder="شماره تلفن ثابت با کد شهر: 02128425220" type="number"
											value={this.state.staticNumber} onChange={this.handleStaticNumberChange} data-parsley-type="digits" data-parsley-pattern="^(?:\(\d{3}\)|\d{3})[- ]?\d{3}[- ]?\d{5}$"/>
										</div>
										<div className="text-center col-sm-12" style={{marginTop: '5px',marginBottom: '5px'}}>
											<span data-html="true" className="text-muted" style={{fontSize: '11px', fontStyle: 'italic'}} data-toggle="why_static_number" data-placement="top" >
												<img src="/img/information.png" alt="" style={{width: '30px'}} />
												چرا شماره تلفن ثابت نیاز است؟
											</span>
										</div>
										<div className="col-sm-12" style={{marginTop: '5%'}}>
											<label htmlFor="email"></label>
											<input className="form-control" required type="email" name="photographer[email]" id="email" placeholder="ایمیل شما"
											value={this.state.emailAddress} onChange={this.handleEmailChange} />
										</div>
										<div className="col-sm-12" style={{marginTop: '5%'}}>
											<label htmlFor="password"></label>
											<input className="form-control" required type="password" name="photographer[password]" id="password" placeholder="رمز عبور جدید &#8203;&#8203; * حداقل ۶ حرف *" 
											value={this.state.password} onChange={this.handlePasswordChange} autoComplete="new-password" data-parsley-minlength='6'
											 />
										</div>
										<div className="col-sm-12" style={{marginTop: '3%'}}>
											<label htmlFor="email"></label>
											<input className="form-control" required type="number" name="photographer[ideal_hours]" id="ideal_hours" placeholder="چند ساعت در هفته علاقه به کار با کادرو دارید؟"
											value={this.state.idealHours} onChange={this.handleIdealHoursChange} />
										</div>
										
									</div>
									<div className="col-sm-6 hidden-xs">
										<img src={(this.props.link)+"/assets/become_kadro-7edccc7bdd9592ac865a78424c4d22eeddaa7854974db58de8224f012a10e37d.jpg"} />
										<div className="col-sm-12" style={{marginTop: '4%'}}>
											<label htmlFor="parent">
											اگر کسی کادرو را به شما معرفی کرده است:
											</label>
											<input className="form-control" type="text" name="photographer[parent_id]" id="parent_id" placeholder="آیدی معرف خود را وارد نمایید"
											value={this.state.parentId} onChange={this.handleParentIdChange} />
										</div>
									</div>
								
									
								</div>
								
								<Address 
									infoCompleted={this.state.infoCompleted}
									continueEnabledCallback={(id) => this.setState({continueEnabled:id})}
									livingAddressCallback={(id) => this.setState({livingAddress:id})}
									
								/>
							</div>
						</div>
					</div>
				</section>
				<footer id="footer">
					<div className="container">
						<div className="wrap">
							<a className="btn btn-gray"  onClick={this.props.previousStep}> بارگشت </a>
							<button type="submit" id="submit_page_form" className="btn btn-blue" onClick={this.handleSubmitButton} disabled={!(this.state.continueEnabled)} >ذخیره و ادامه
							</button>
						</div>
					</div>
				</footer>
			</React.Fragment>
		);
	}
}

