class Equipments extends React.Component {
	constructor() {
		super();
		this.state = {
			cameraEquipments:[],
			lenzEquipments:[],
			kitEquipments:[],
			checkedKitEquipments:[],
		};
		this.handleSubmitButton=this.handleSubmitButton.bind(this);
		this.callEquipmentsApi=this.callEquipmentsApi.bind(this);
	}
	componentDidMount(){

	  
	    
	}
	componentWillReceiveProps(nextProps){
		if(nextProps.lenzEquipments!==this.props.lenzEquipments || nextProps.cameraEquipments!==this.props.cameraEquipments)
        {  
        	$('.cameras').dropdown('clear');  
			$('.lenzes').dropdown('clear');  
			
            this.setState({lenzEquipments:nextProps.lenzEquipments});
            this.setState({cameraEquipments:nextProps.cameraEquipments});
            this.setState({kitEquipments:nextProps.kitEquipments});

    
			
		}
	}
	handleSubmitButton(){
		this.callEquipmentsApi();
		this.props.nextStep();
	}
	callEquipmentsApi(){
		let kitValuesSelected=[];
		this.state.kitEquipments
			.map((object) => 
			{

				let rowItems=object.map((rowItem)=>
				{
					if($("input[id="+(rowItem.id)+"]").prop("checked") == true)
					{
						kitValuesSelected.push(rowItem.id);
					}

				});

				
				
			});
		let cameraValuesSelected=$( "input[name=camera]" ).val();
		let lenzValuesSelected=$( "input[name=lenz]" ).val();
		

		let cameraValuesSelectedArray=[];
		let cameraValuesSelectedSplitted = cameraValuesSelected.split(",");
		for (var i = 0; i < cameraValuesSelectedSplitted.length; i++) {
		    cameraValuesSelectedArray.push( parseInt(cameraValuesSelectedSplitted[i]));
		}

		let lenzValuesSelectedArray=[];
		let lenzValuesSelectedSplitted = lenzValuesSelected.split(",");
		for (var i = 0; i < lenzValuesSelectedSplitted.length; i++) {
		    lenzValuesSelectedArray.push( parseInt(lenzValuesSelectedSplitted[i]));
		}



		let data={
			
			kit_id:kitValuesSelected,
			camera_id:cameraValuesSelectedArray,
			lenz_id:lenzValuesSelectedArray,
			photographer_id:this.props.photographerId
		}
		let body = JSON.stringify(data);
        let url=this.props.link+'/api/v1/equipments';
		return fetch(url, {method:'post',
		            body: body,
		            headers: { "Content-Type": "application/json","Accept":"application/json"  ,"Authorization":this.props.token}})
		       
		
	}
	render () {
		let cameraItems;
		let lenzItems;
		let kitItems;
		let persianDigits = "۰۱۲۳۴۵۶۷۸۹";
        let persianMap = persianDigits.split("");
		if(this.state.cameraEquipments.length==0 )
		{
			cameraItems=<div className="item" style={{direction: 'ltr'}}>
			</div>
		}
		else{
			cameraItems=this.state.cameraEquipments
			.map((object) =>
	    	{

				return(
					<div data-value={object.id} data-text={(object.brand)+" "+(object.model)} className="item" style={{direction: 'ltr'}}>
						{(object.brand)+" "+(object.model)}
					</div>
				);
			});
		}
		if(this.state.lenzEquipments.length==0)
		{
			lenzItems=<div className="item" style={{direction: 'ltr'}}></div>
		}
		else{
			lenzItems=this.state.lenzEquipments
			.map((object) =>
	    	{

				return(
					<div data-value={object.id} data-text={(object.brand)+" "+(object.model)} className="item" style={{direction: 'ltr'}}>
						{(object.brand)+" "+(object.model)}
					</div>
				);
			});
		}

		if(this.state.kitEquipments.length==0)
		{
			kitItems=<React.Fragment></React.Fragment>;
		}
		else{
		

			kitItems=this.state.kitEquipments
			.map((object) => 
			{

				let rowItems=object.map((rowItem)=>
				{
					let kitSubItems=rowItem.photography_tools.map((item,i)=>
					{
						let index=i+1;
						if(item.count!==0)
						{
							return(	
									<React.Fragment>
										<a className="kit-item">{(index.toString().replace(/\d/g, function (m) {
						                                        return persianMap[parseInt(m)];
						                                    }))+') '+(item.count.toString().replace(/\d/g, function (m) {
						                                        return persianMap[parseInt(m)];
						                                    }))+' عدد '+(item.name)}</a>
										<br />
									
									</React.Fragment>
								);
						}
						else{
							return(	
									<React.Fragment>
										<a className="kit-item">{(index.toString().replace(/\d/g, function (m) {
						                                return persianMap[parseInt(m)];
						                            }))+') '+(item.name)}</a>
										<br />
									
									</React.Fragment>
								);
						}
					});
					return(
						
						
							<div className="col-sm-6">
								<div className="col-sm-6">
									<div className="checkbox-control">
										<input type="checkbox" id={rowItem.id} value="1" name="kit-check-box" />
										<label htmlFor="large-product-kit">
										{rowItem.persian_title}
										</label>
										
									</div>
								</div>
								<div className="col-sm-6">
									<small>
										{kitSubItems}
									</small>
								</div>
							</div>
							
						
					
					);
				});

				return(
					<React.Fragment>
						<div className="row">
							{rowItems}
						</div>
						<hr />	
					</React.Fragment>

				);
				
			});
				
				
			
		}
		
		

		
		return (
			<React.Fragment>
				<section id="main">
					<div className="container">
						<div className="main">
							<div className="tracker">
								<div className="process-tabs-line w-hidden-tiny">
									<span className="step-line step-line-package active" style={{width: "33.3333%" ,right: "0%"}}></span>
									<span className="step-line step-line-datetime " style={{width: '33.3333%', right: '33.3333%'}}></span>
									<span className="step-line step-line-details" style={{width:'33.3333%',right: '66.6667%'}}></span>
								</div>
								<div className="process-tab-button tracker-circle selected" style={{right: '0%'}}>
									<div className="tracker-text">
									اطلاعات اولیه
									</div>
								</div>
								<div className="process-tab-button tracker-circle selected " style={{right: '33.3333%'}}>
									<div className="tracker-text">
									تجهیزات عکاسی
									</div>
								</div>
								<div className="process-tab-button tracker-circle" style={{right: '66.6667%'}}>
									<div className="tracker-text">
									نمونه کارها
									</div>
								</div>
								<div className="process-tab-button tracker-circle" style={{right: '100%'}}>
									<div className="tracker-text">
									تجربه کاری
									</div>
								</div>
							</div>
							<div className="wrapper">
								<div className="row" style={{marginBottom: '30px'}}>
									<div className="col-sm-12">
										<p className="text-center">
									      به ما بگویید تجهیزات عکاسی چه دارید.
									      <br />
									      این به ما کمک می کند بدانیم شما
									      از پس چه کارهایی بر می آیید.
									    </p>
									    <hr />

									</div>
									<div className="col-sm-6">
										<div className="col-sm-12">
											<label htmlFor="name">
											دوربین
											</label>
											<div className="cameras ui fluid multiple search normal selection dropdown">
												<input type="hidden" name="camera" required />
														<i className="dropdown icon"></i>
												<div className="default text">
												انتخاب ...
												</div>
												<div className="menu">
											
													
													{cameraItems}
														
													
												</div>
											</div>
										</div>
									</div>
									<div className="col-sm-6">
										<div className="col-sm-12">
											<label htmlFor="name">
											لنز
											</label>
											<div className="lenzes ui fluid multiple search normal selection dropdown">
												<input type="hidden" name="lenz" required />
													<i className="dropdown icon"></i>
												<div className="default text">
												انتخاب ...
												</div>
												<div className="menu">										
													
													{lenzItems}

												</div>
											</div>
										</div>
									</div>
								</div>
								<div className="row">
									<div className="col-sm-12">
										<label htmlFor="name">
										لوازم جانبی
										</label>
										
									 	{kitItems}
											
											
											
										
										
										
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>
				<footer id="footer">
					<div className="container">
						<div className="wrap">
						  <a className="btn btn-gray"  onClick={this.props.previousStep}> بارگشت </a>
						  <button type="submit" id = "submit_page_form"  className="btn btn-blue" onClick={this.handleSubmitButton} >ذخیره و ادامه
						  </button>
						</div>
					</div>
				</footer>
		</React.Fragment>
		);
	}
}