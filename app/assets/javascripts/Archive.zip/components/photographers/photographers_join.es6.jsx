class PhotographersJoin extends React.Component {
	constructor() {
        super();
        this.state = {
        	step: 1 ,
            infoFieldValues:{},
            lenzEquipments:[],
            cameraEquipments:[],
            kitEquipments:[],
		};
    	this.nextStep = this.nextStep.bind(this);
    	this.previousStep = this.previousStep.bind(this);
    }
    nextStep() {
	  this.setState({
	    step : this.state.step + 1
	  });
	  $("html, body").animate({ scrollTop: 0 }, "slow");
	}
	previousStep() {
	  this.setState({
	    step : this.state.step - 1
	  });
	  $('html, body').animate({scrollTop:$(document).height()}, 'slow');
	}
	render () {
		return(
			<React.Fragment>
				
				<div style={{display: (this.state.step==1)?'':'none'}}>
					<Info 
					infoComponentFieldValues={(Id) => this.setState({infoFieldValues:Id})}
					lenzEquipmentCallBack={(Id) => this.setState({lenzEquipments:Id})}
					cameraEquipmentCallBack={(Id) => this.setState({cameraEquipments:Id})}
					kitEquipmentCallBack={(Id) => this.setState({kitEquipments:Id})}
					link={this.props.link}
					nextStep={this.nextStep}
					previousStep={this.previousStep}
					/>;
				</div>
				<div style={{display: (this.state.step==2)?'':'none'}}>
					<Equipments 
					photographerId={this.state.infoFieldValues['photographerId']}
					token={this.state.infoFieldValues['token']}
					lenzEquipments={this.state.lenzEquipments}
					cameraEquipments={this.state.cameraEquipments}
					kitEquipments={this.state.kitEquipments}
					link={this.props.link}
					nextStep={this.nextStep}
					previousStep={this.previousStep}
					/>;
				</div>
				<div style={{display: (this.state.step==3)?'':'none'}}>
					<SocialInfos 
					link={this.props.link}
					nextStep={this.nextStep}
					previousStep={this.previousStep}
					photographerId={this.state.infoFieldValues['photographerId']}
					token={this.state.infoFieldValues['token']}
					/>;
				</div>
			</React.Fragment>
		);
	}
}