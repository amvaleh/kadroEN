class PhotoUpload extends React.Component {
	constructor() {
		super();
		this.state = {


		};

	}
	render () {
		if(this.props.step=="photo")	
		{
			return (
				<React.Fragment>
					<div id="photo-upload" className="row" style={{marginBottom: '30px'}}>
						<div className="col-sm-12">
							<h3>
							رشته های عکاسی
							</h3>
							<h5 style={{lineHeight: '22px'}}>
							لطفا همه رشته هایی عکاسی ای که دوست دارید سفارش عکاسی دریافت کنید را انتخاب کنید.
							انتخاب هر چه بیشتر رشته ها منجر به پروژه های عکاسی بیشتری برای شما خواهد شد.
							</h5>

							<div className="wrapper " id="detail">
								<div id="specialities" className="specialties">
									<ul id="business" className="row row-m10">
										{/*<% ShootType.all.order("shoot_types.order desc").each do |s| %>*/}
										<li className="col-xs-4 col-sm-4 col-md-4">
											<div href="#" className="specialty">
												{/*<%if Expertise.where(:shoot_type => s , :photographer => @photographer).any? %>
												selected
												<%end%>" id="<%=s.id%>" onclick="$(this).animate_field('sp<%=s.id%>', <%=s.packages.count/2%>)">*/}
												<img src="<%=s.avatar_url%>" alt="" />
												<span>
												{/*<%= s.title%>*/}
												</span>
											</div>
										</li>
										{/*<% end %>*/}
									</ul>
								</div>
							</div>
						</div>
						
						<div id="forms_holder">
							{/*<% ShootType.all.order("shoot_types.order desc").each do |s| %>*/}
							{/*<div className="col-sm-12">*/}
								{/*<% exp = Expertise.where(:shoot_type => s , :photographer => @photographer) %>
								<%if not exp.any?%>hidden<%end%>" id="expertise_sp<%=s.id%>">
								<%= form_tag(receive_photo_photographer_path(@photographer), class:"fileupload",:multipart => true ,method: 'post', remote: true ) do %>
								*/}
								{/*<noscript>
									<input type="hidden" name="redirect" value="http://blueimp.github.io/jQuery-File-Upload/" /> 		
								</noscript>
								<div className="row fileupload-buttonbar">
									<div style={{lineHeight: '30px'}}>*/}
									{/*<!-- The fileinput-button span is used to style the file input field as button -->*/}
										{/*<h2>*/}{/*<%= s.title %>*/}{/*</h2>
										<p>
											<span style={{color:'red'}}>
											*
											</span>
											عرض و طول هر عکس بین ۱۵۰۰ پیکسل تا ۱۰.۰۰۰ پیکسل باشد
										</p>
										<p style={{fontStyle: 'italic'}}>
											<span style={{color:'red'}}>
											*
											</span>
											شما باید حداقل ۳ نمونه کار
											<strong style={{textDecoration: 'underline'}}>
											بدون واترمارک
											</strong>
											آپلود کنید.
										</p>
									</div>*/}
									{/*<% if Expertise.where(:shoot_type => s , :photographer => @photographer).any? %>
									<% exp = Expertise.where(:shoot_type => s , :photographer => @photographer).first %>
									<%= link_to remove_expertise_photographer_path(expertise_id: exp.id) , remote: true,class: "btn btn-xs text-danger " do%>
									<%= image_tag("/assets/close.png", :alt => "حذف رشته انتخابی", :title => "delete",width: "10px") %>*/}
									{/*حذف
									رشته*/}
									{/*<%= exp.shoot_type.title %>
									<%end%>*/}
									{/*<table role="presentation" className="table table-hover">
										<tbody className="files" id="shoot_type_<%=s.id%>">*/}
											{/*<!-- current photos -->
											<% exp.photos.each do |p| %>*/}
											{/*<tr className="template-download" id="expertise_<%=exp.id%>">
												<td className="preview">*/}
												{/*<%= link_to p.file_url(:medium) do %>
												<%= image_tag p.file_url(:thumb) , rel: "gallery"%>
												<% end %>*/}
												{/*</td>
												<td className="name">*/}
												{/*<%=File.basename(p.file_url) %>*/}
												{/*</td>
												<td className="size">
													<span>*/}
													{/*<%= number_to_human_size(p.file.size) %>*/}
													{/*</span>
												</td>
												<td colSpan="2">
												</td>
												<td className="delete">*/}
													{/*<%= link_to p , class: "btn btn-xs text-danger " , method: :delete, :remote => true do %>
													<%= image_tag("/assets/close.png", :alt => "حذف رشته انتخابی", :title => "delete",width: "10px") %>*/}
													{/*حذف عکس*/}
													{/*<% end %>*/}
												{/*</td>
											</tr>*/}
											{/*<% end %>
											<% end %>
											*/}
										{/*</tbody>
									</table>
									<span className="btn fileinput-button btn-blue" style={{padding: '25px 25px', background: 'black'}}>
										<i className="icon-plus icon-white"></i>
										<span>
											انتخاب نمونه کار*/}
											{/*<%= s.title %>*/}
										{/*</span>*/}
											{/*<%= hidden_field_tag :shoot_type_id , s.id %>
											<%= file_field_tag :file, multiple: true, id: 'upload-field' %>*/}
									{/*</span>
									<div className="span5 fileupload-progress fade">*/}
										{/*<!-- The global progress bar -->*/}
										{/*<div className="progress progress-success progress-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100">
											<div className="bar" style={{width:'0%'}}>
											</div>
										</div>*/}
										{/*<!-- The extended global progress information -->*/}
										{/*<div className="progress-extended" style={{direction: 'ltr !important'}}>&nbsp;
										</div>
									</div>
								</div>*/}
								{/*<% end %>*/}
							{/*</div>*/}
							{/*<% end %>*/}
						</div>
					</div>
				</React.Fragment>
			);
		}
		else{
			return(
				<div id="photo-upload" className="row" style={{marginBottom: '30px'}}>
				</div>
				);

		}
	
	}
}