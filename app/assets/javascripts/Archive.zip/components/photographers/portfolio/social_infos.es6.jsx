class SocialInfos extends React.Component {
	constructor() {
		super();
		this.state = {
			uid:'',
			instagramId:'',
			twitterId:'',
			linkedin:'',
			website:'',
			step:'portfolio'
		};
		this.handleUidChange = this.handleUidChange.bind(this);
		this.handleInstagramIdChange=this.handleInstagramIdChange.bind(this);
		this.handleTwitterIdChange=this.handleTwitterIdChange.bind(this);
		this.handleLinkedinChange=this.handleLinkedinChange.bind(this);
		this.handleWebsiteChange=this.handleWebsiteChange.bind(this);
		this.handleAvatarUploadButton=this.handleAvatarUploadButton.bind(this);
		this.handleSubmitButton=this.handleSubmitButton.bind(this);
		this.handleInformationValidation=this.handleInformationValidation.bind(this)
	};

	componentDidMount(){
		
	}
	componentWillReceiveProps(nextProps){
		if(nextProps.photographerId!==this.props.photographerId)
        {
        	this.setState({step:"portfolio"});
		}
	}
	handleInformationValidation(){

		$('#uid').parsley().validate();
		$('#imgInp').parsley().validate();
		if(!$('#uid').parsley().isValid() || !$('#imgInp').parsley().isValid() )
		{	
            formIsValid = false;
        }
        else{
           formIsValid = true; 
        }
		
      	return formIsValid;
	}
	handleSubmitButton()
	{
		if(this.state.step="portfolio")
		{
			if(this.handleInformationValidation())
			{
				this.callPortfolioApi();
				
			}
			else{
				console.log("error");
			}
		}
		else{

		}
	}	
	handleAvatarUploadButton(event){
		console.log("handleAvatarUploadButton");
		
		$("#imgInp").trigger('click');
		$("#imgInp").on("change", (changeEvt)=> {
			this.setState({step:'portfolio'})
    		readURL(changeEvt.target);
	  	});
	}
	handleUidChange(event){
		this.setState({uid: event.target.value});
		this.setState({step:"portfolio"});
		$('#uid').parsley().validate();
	}
	handleInstagramIdChange(event){
		this.setState({instagramId: event.target.value});
		this.setState({step:"portfolio"});
	}
	handleTwitterIdChange(event){
		this.setState({twitterId: event.target.value});
		this.setState({step:"portfolio"});
	}
	handleLinkedinChange(event){
		this.setState({linkedin: event.target.value});
		this.setState({step:"portfolio"});
	}
	handleWebsiteChange(event){
		this.setState({website: event.target.value});
		this.setState({step:"portfolio"});
	}
	callPortfolioApi(){
		let formData = new FormData();
		let photo = document.getElementById('imgInp').files[0];
		formData.append('photographer[avatar]', photo);
		formData.append('photographer[uid]', this.state.uid);
		formData.append('photographer[instagram]', this.state.instagramId);
		formData.append('photographer[twitter]', this.state.twitterId);
		formData.append('photographer[online_portfolio]', this.state.website);
		formData.append('photographer[linkedin]', this.state.linkedin);
		formData.append('photographer[id]', this.props.photographerId);

        let url=this.props.link+'/api/v1/photographers_portfolio';
        //console.log(this.props.token);
        return fetch(url, {method:'post',
            body: formData,
            headers: { "Accept":"application/json" ,"Authorization":this.props.token}})
             .then((response)=>{
            	//console.log("response photographers: ");
            	//console.log(response);
            	//console.log(response.status);
            	if (parseInt(response.status) !== 200) {

            		response.json().then((object) =>{
            			//console.log("response errors:");
            			//console.log(object.errors);
                	
                		//move up
                		$("html, body").animate({ scrollTop: 0 }, "slow");
    				});
            	}
                else{
					
                	response.json().then((object) =>{
                		
                		this.setState({step:"photo"});
						var target = $('#photo-upload');
						if( target.length ) {
			              $('html, body').stop().animate({
			                  scrollTop: target.offset().top
			              }, 1000);
			            }
                        //console.log(object.photographer.token);		
                        //console.log(object.photographer.id);	
    				});
                    
                }
     
            	
            	
            })
            .catch(function(e){console.log(e)});
	}
	render () {
		return (
			<React.Fragment>
				<section id="main">
					<div className="container">
						<div className="main">
							<div className="tracker">
								<div className="process-tabs-line w-hidden-tiny">
									<span className="step-line step-line-package active" style={{width: "33.3333%" ,right: "0%"}}></span>
									<span className="step-line step-line-datetime active" style={{width: '33.3333%', right: '33.3333%'}}></span>
									<span className="step-line step-line-details" style={{width:'33.3333%',right: '66.6667%'}}></span>
								</div>
								<div className="process-tab-button tracker-circle selected" style={{right: '0%'}}>
									<div className="tracker-text">
									اطلاعات اولیه
									</div>
								</div>
								<div className="process-tab-button tracker-circle selected " style={{right: '33.3333%'}}>
									<div className="tracker-text">
									تجهیزات عکاسی
									</div>
								</div>
								<div className="process-tab-button tracker-circle selected" style={{right: '66.6667%'}}>
									<div className="tracker-text">
									نمونه کارها
									</div>
								</div>
								<div className="process-tab-button tracker-circle" style={{right: '100%'}}>
									<div className="tracker-text">
									تجربه کاری
									</div>
								</div>
							</div>
							<div className="wrapper">
								<div className="row" style={{marginBottom: '30px'}}>
									<div className="col-sm-12">
										<p className="text-center">
										بهترین نمونه عکس های تان را آپلود کنید،
										<br />
										تا
										مشتریان
										با سبک و سلیقه کاری شما آشنا شوند.
										<br />
										آپلود عکس های غیر تکراری برای ارزیابی شما مفیدتر می باشد.
										<br />
										<small>
										(
										عکس ها در صفحه شما نمایش داده خواهند شد
										)
										</small>
										</p>
										<hr />
									</div>
									<input type='file' id="imgInp" style={{ display: "none"}}/>
									<div className="col-sm-6">
										<div className="col-sm-12">
											<h5 htmlFor="">
												عکس پرتره حرفه ای از خودتان
												<span style={{color:'red'}}>
												{" * "}
												</span>
												<small className="text-muted">
												jpeg فقط-
												700px x 700px
												</small>
											</h5>
											<small>
											(
											بانوان لطفا عکسی با حجاب و مطابق قوانین جمهوری اسلامی انتخاب کنند
											)
											</small>
											<div className="col-sm-9 text-center well">
												<img id="avatar_upload_preview" src="<%=@photographer.avatar_url if @photographer.avatar.present?%>" alt="your image" className="img-reponsive " />
											</div>
											<div className="col-sm-3">
												<div className="btn btn-blue" id="profile-pic" onClick={this.handleAvatarUploadButton}>
												انتخاب
												</div>

											</div>

										</div>
										<div className="col-sm-12" id="uploadSizeError" style={{ display: "none"}}>
										  <p style={{ color: "red" ,textDecoration: 'none' }}>
										   اندازه عکس باید ۷۰۰ پیکسل در ۷۰۰ پیکسل باشد، لطفا مجدد آپلود کنید.
										  </p>
										  </div>
										<div className="col-sm-12">
									    	<h5>
												<span style={{color:'red'}}>
												*
												</span>
												یک آی دی برای صفحه خود انتخاب کنید:
												<small className="pull-left">
												به عنوان مثال:
													<span style={{fontSize: '15px'}}>
													<a target="blank" href="http://bahmann810.kadro.co/">bahman810.kadro.co</a>
													{/*<%=link_to "bahman810.kadro.co","http://bahmann810.kadro.co/" , target: :blank %>*/}
													</span>
												</small>
											</h5>
											<div className="input-group">
												<span className="input-group-addon" style={{fontSize:'20px'}}  > kadro.co. </span>
												{/*<%= f.text_field "uid" , class: "form-control text-center ltr mytextbox" , 'required' => "",  'aria-describedby'=> "uid" ,placeholder: "فقط یک نام یکتا وارد کنید" %>*/}
												<input className="form-control text-center ltr mytextbox"
												 id="uid" aria-describedby="uid" placeholder="فقط یک نام یکتا وارد کنید"  type="text" 
												 value={this.state.uid} onChange={this.handleUidChange} 
												 data-parsley-pattern="^[a-z]+[a-z0-9]*$"
												 data-parsley-pattern-message="این مقدار مورد قبول نمی باشد (غیر از حروف انگلیسی کوچک و عدد مورد قبول نیست و حرف شروع نباید عدد باشد)"
												 />
											</div>
										</div>
										<div className="col-sm-12">
											<h5>
											آی دی اینستاگرام شما
											</h5>
											<div className="input-group">
												{/*<%= f.text_field "instagram" , class: "form-control ltr",  'aria-describedby'=> "instagram" ,placeholder: "فقط آی دی را وارد کنید" %>*/}
												<input className="form-control ltr" aria-describedby="instagram" placeholder="فقط آی دی را وارد کنید" type="text"
												value={this.state.instagramId} onChange={this.handleInstagramIdChange} 
												 />
												<span className="input-group-addon" style={{fontSize:'20px'}} id="instagram">/https://instagram.com</span>
											</div>

										</div>
										

										
									</div>
									<div className="col-sm-6">
										<div className="col-sm-12 left">
											<h5>
											آی دی توییتر
											</h5>
											{/*<%#= f.text_field "twitter" , class: "form-control ltr"%>*/}
											<div className="input-group">
												{/*<%= f.text_field "twitter" , class: "form-control ltr",  'aria-describedby'=> "twitter" ,placeholder: "فقط آی دی را وارد کنید" %>*/}
												<input className="form-control ltr" aria-describedby="twitter" placeholder="فقط آی دی را وارد کنید" type="text"
												value={this.state.twitterId} onChange={this.handleTwitterIdChange} 
												 />
												<span className="input-group-addon" style={{fontSize:'20px'}} id="instagram">/https://twitter.com</span>
											</div>
										</div>
										<div className="col-sm-12 left">
											<h5>
											لینک صفحه لینکداین شما
											</h5>
											{/*<%= f.text_field "linkedin" , class: "form-control ltr" ,placeholder: "https://www.linkedin.com/in/"%>*/}
											<input className="form-control ltr" type="text" placeholder="https://www.linkedin.com/in/" 
											value={this.state.linkedin} onChange={this.handleLinkedinChange} 
											/> 
										</div>
										<div className="col-sm-12">
											<h5>
											وب سایت شخصی
											</h5>
											<input className="form-control ltr" type="text" placeholder="www.example.com"
											value={this.state.website} onChange={this.handleWebsiteChange}
											 />
											{/*<%= f.text_field "online_portfolio" , class: "form-control ltr" ,placeholder: "www.example.com"%>*/}
										</div>
									</div>
								</div>
								<PhotoUpload 
								step={this.state.step}
								/>
							</div>
						</div>
					
					</div>{/*<!-- /.main -->*/}
				</section>
				<footer id="footer">
				  <div className="container">
				    <div className="wrap">
				      {/*<%= link_to "بازگشت" ,  equipments_photographer_path(@photographer) , class:"btn btn-gray" %>*/}
				      <a className="btn btn-gray"  onClick={this.props.previousStep}> بارگشت </a>
				      <button type="submit" id ="submit_page_form" className="btn btn-blue" onClick={this.handleSubmitButton} >ذخیره و ادامه
				      </button>
				    </div>
				  </div>
				</footer>
			</React.Fragment>
		);
	}
}