class Details extends React.Component {

	constructor() {
			super();
			this.state = {
				checkOneSelected:false,
				checkTwoSelected:false,
				feedbackSelectedId: -1,
				styleDetails:'',

			};
			this.handleSubmitButton=this.handleSubmitButton.bind(this);
			this.handleStyleDetailsChange=this.handleStyleDetailsChange.bind(this);
			this.handleSelectOptionsChange=this.handleSelectOptionsChange.bind(this);
			this.handleCheckOneSelectedChange=this.handleCheckOneSelectedChange.bind(this);
			this.handleCheckTwoSelectedChange=this.handleCheckTwoSelectedChange.bind(this)
	}
	componentDidMount(){
		$("#feedback_channel").prepend("<option value='' selected='selected'>انتخاب کنید</option>");
	}
	componentWillReceiveProps(nextProps){
		var timer= new timer_interface();
		
		if(nextProps.photographerSelectedId !== this.props.photographerSelectedId)
        {
        	timer.stop();
        	timer.start();
        }
        $('#submit_page_form').on('click', ()=> {
        	timer.stop();
		});

    }
    handleSubmitButton(){
    	///submit detail api call
		let url=this.props.link+"/api/v1/submit_detail";
		let body="detail[feedback_channel_id]="+this.state.feedbackSelectedId+"&detail[shoot_detail]="+this.state.styleDetails+"&project_slug="+this.props.project_slug;

		fetch(url, {method:'post',
            body: body,
            headers: { "Content-Type": "application/x-www-form-urlencoded","Accept":"application/json" ,"Authorization":this.props.token }})
            .then((response)=>{

            	if (parseInt(response.status) != 202) {
            		response.json().then((object) =>{
            			console.log("response error:"+object);

    				});

            	}
                else{


                	response.json().then((object) =>{

                		this.props.subtotal(object.subtotal);
            		});
            		this.props.nextStep();

    			}



				}).catch(function(e){console.log(e)});
    }
	handleStyleDetailsChange(event){
        this.setState({styleDetails: event.target.value});
    }
    handleSelectOptionsChange(event){
        this.setState({feedbackSelectedId: event.target.value});
    }
    handleCheckOneSelectedChange(event){
    	this.setState({checkOneSelected: event.target.checked});
    }
    handleCheckTwoSelectedChange(event){
    	this.setState({checkTwoSelected: event.target.checked});
    }
	render () {

		let options=this.props.feedbacks
		.sort((a, b) => a['id'] > b['id'])
		.map((object,index) =>
		{
			return(
				<option value={object.id}>{object.title}</option>
			);
		});
	    return (
			<React.Fragment>
				<section id="main">
					<div className="container">
						<div className="main">
							<div className="tracker-container">
								<div className="tracker">
									<div className="process-tabs-line w-hidden-tiny">
										<span className="step-line step-line-package active" style={{width: '33.3333%', right: '0%'}}></span>
										<span className="step-line step-line-datetime active" style={{width: '33.3333%', right: '33.3333%'}}></span>
										<span className="step-line step-line-details active" style={{width: '33.3333%', right: '66.6667%'}}></span>
									</div>

									<div className="process-tab-button tracker-circle selected" style={{right: '0%'}}>
										<div className="tracker-text">
										پکیج
										</div>
									</div>
									<div className="process-tab-button tracker-circle selected" style={{right: '33.3333%'}}>
										<div className="tracker-text">
										کی و کجا؟
										</div>
									</div>
									<div className="process-tab-button tracker-circle selected" style={{right: '66.6667%'}}>
										<div className="tracker-text">
										عکاس
										</div>
									</div>
									<div className="process-tab-button tracker-circle selected" style={{right: '100%'}}>
										<div className="tracker-text">
										جزئیات
										</div>
									</div>
								</div>
							</div>
							<div className="wrapper">
								<div className="pie-container">
									<div className="pie">
										<div id="rotate" className="pie-rotate" style={{backgroundColor: 'rgb(42, 134, 249)', transform: 'rotate(-355.2deg)'}}>
										</div>
										<div id="timer" className="pie-center">9:53
										</div>
									</div>
									<p>
									دقیقه
									رزرو این عکاس برای شما محفوظ خواهد بود.
									</p>
								</div>
								<p id="after-count" className="hidden">
								ممکن هست در صورتیکه شخص دیگری عکاس را رزرو کرده باشد باید به مرحله قبل بازگردید.

								</p>
								<br />
								<h3>
								نهایی سازی
								</h3>
								<div className="row" id="detail">
									<div className="col-sm-6">
										<div className="form-group">
											<label for="address-detail">
											استایل عکاسی
											</label>
											<textarea
											name="shoot-style"
											rows="5"
											className="form-control"
											id="address-detail"
											placeholder="استایل تصاویری که دوست دارید بگیرید، لینک به نمونه های مشابه یا هر چیزی (ببینیم چه کار براتون می تونیم بکنیم)"
											value={this.state.styleDetails}
											onChange={this.handleStyleDetailsChange}
											>
											</textarea>
										</div>{/* /.form-group */}

										<div className="form-group" style={{marginTop: "30px"}}>
											<div className="checkbox-control">
												<input
												type="checkbox"
												id="check1"
												value="انتخاب توافق"
												required=""
												data-parsley-multiple="check1"
												checked={this.state.checkOneSelected}
            									onChange={this.handleCheckOneSelectedChange}
            									/>
												<label for="check1">"من <a href="https://kadro.co/terms/" target="_blank">شرایط و مقررات</a> کادرو را خوانده و پذیرفته ام."</label>
											</div>
											<div className="checkbox-control">
												<input
												type="checkbox"
												id="check2"
												value="قوانین"
												required=""
												data-parsley-multiple="check2"
												checked={this.state.checkTwoSelected}
            									onChange={this.handleCheckTwoSelectedChange}
												/>
												<label for="check2">
												  من با شرط لغو زیر موافق هستم:
												</label>
											</div>
										</div>{/* /.form-group */}
										<p style={{color: "#b2bcc7", fontSize: "0.9em"}}>
											زمان و مکان پروژه تا ۲۴ ساعت مانده به رزرو شما
											قابل تغییر نیست.
											اولین تغییر زمان یا مکان بدون هزینه انجام می شود، تغییر های
											بعدی مستلزم پرداخت هزینه است.
											هیچ بازپرداخت مبلغی
											در صورت
											کنسلی یا عدم حضور شما در زمان پروژه وجود ندارد.
										</p>
									</div>
									<div className="col-sm-6">
										<div className="form-group">
											<label for="shooter-detail">نحوه آشنایی با ما</label>

											<select name="feedback_channel" id="feedback_channel" className="form-control" value={this.state.feedbackSelectedId} onChange={this.handleSelectOptionsChange}>
												{options}

											</select>
										</div>

									</div>{/* /.col sm 6 */}
								</div>
							</div>{/* /.wrapper */}
						</div>{/* /.main */}
					</div>{/* /.container -->*/}
					<footer id="footer">
						<div className="container">
							<div className="wrap">
								<a className="btn btn-gray" onClick={this.props.previousStep} >بازگشت</a>
								<button type="submit" id="submit_page_form" className="btn btn-blue" onClick={this.handleSubmitButton} disabled={!(this.state.checkOneSelected&&this.state.checkTwoSelected) }>ذخیره و ادامه</button>
							</div>
						</div>
					</footer>
				</section>
			</React.Fragment>
	    );
  	}
}
