class Main extends React.Component {
	constructor() {
        super();
        this.state = {
            step: 1 ,
            token: '',
            project_slug: '',
            selectedServicePackageId: '',
            shootTypeSelectedId:'',
            shootTypeSelectedTitle:'',
            availablePhotographers:[],
            photographersPhotos:{},
            photographerSelectedId:'',
            feedbacks:[],
            dateTimeSelected:'',
            subtotal:-1,
            addressLng:'',
            addressLat:'',
            addressInput:'',
            addressDetail:'',
            receiptPackageFieldValues : {},
            receiptWhereFieldValues : {},
            receiptPhotographersFieldValues:{}
        };
    	this.nextStep = this.nextStep.bind(this);
    	this.previousStep = this.previousStep.bind(this);
    }
    nextStep() {
	  this.setState({
	    step : this.state.step + 1
	  });
	  $("html, body").animate({ scrollTop: 0 }, "slow");
	}

// Same as nextStep, but decrementing
	previousStep() {
	  this.setState({
	    step : this.state.step - 1
	  });
	  $('html, body').animate({scrollTop:$(document).height()}, 'slow');
	}

	render () {
			return(
				<React.Fragment>
					<h1>{this.props.appointments}</h1>
					<div style={{display: (this.state.step==1)?'':'none'}}>
						<Package 
						selectedServicePackageIdCallBack={(id) => this.setState({selectedServicePackageId:id})}
						shoot_type_selected_id_callBack1={(id) => this.setState({shootTypeSelectedId:id})}
						shoot_type_selected_title_callBack={(id) => this.setState({shootTypeSelectedTitle:id})}
						project_slug={(slug) => this.setState({project_slug:slug})}
						token={(t) => this.setState({token:t})}
						nextStep={this.nextStep}
						previousStep={this.previousStep}
						receiptPackageFieldValues={(id) => this.setState({receiptPackageFieldValues:id})}
						email_address={this.props.email_address}
						first_name={this.props.first_name}
						last_name={this.props.last_name}
						mobile_number={this.props.mobile_number}
						link={this.props.link}
						/>;
					</div>
					<div style={{display: (this.state.step==2)?'':'none'}}>
						<WhereAndWhen  
						project_slug={this.state.project_slug} 
						token={this.state.token}
						nextStep={this.nextStep}
						previousStep={this.previousStep}
						shootTypeSelectedId={this.state.shootTypeSelectedId}
						availablePhotographers={(id) => this.setState({availablePhotographers:id})}
						selectedServicePackageId={this.state.selectedServicePackageId}
						photographersPhotos={(id) => this.setState({photographersPhotos:id})}
						dateTimeSelected={(id) => this.setState({dateTimeSelected:id})}
						receiptWhereFieldValues={(id) => this.setState({receiptWhereFieldValues:id})}
						link={this.props.link}
						/>
					</div>
					<div style={{display: (this.state.step==3)?'':'none'}}>
						<Photographers 
						project_slug={this.state.project_slug} 
						token={this.state.token}
						availablePhotographers={this.state.availablePhotographers}
						photographersPhotos={this.state.photographersPhotos}
						shootTypeSelectedTitle={this.state.shootTypeSelectedTitle}
						previousStep={this.previousStep}
						nextStep={this.nextStep}
						feedbacks={(id) => this.setState({feedbacks:id})}
						photographerSelectedId={(id) => this.setState({photographerSelectedId:id})}
						dateTimeSelected={this.state.dateTimeSelected}
						receiptPhotographersFieldValues={(id) => this.setState({receiptPhotographersFieldValues:id})}
						link={this.props.link}
						/>
					</div>
					<div style={{display: (this.state.step==4)?'':'none'}}>
						<Details 
						project_slug={this.state.project_slug} 
						token={this.state.token}
						nextStep={this.nextStep}
						previousStep={this.previousStep}
						feedbacks={this.state.feedbacks}
						photographerSelectedId={this.state.photographerSelectedId}
						subtotal={(id) => this.setState({subtotal:id})}
						link={this.props.link}
						/>
					</div>
					<div style={{display: (this.state.step==5)?'':'none'}}>
						<Receipt
						project_slug={this.state.project_slug} 
						token={this.state.token}
						nextStep={this.nextStep}
						previousStep={this.previousStep}
						subtotal={this.state.subtotal}
						receiptWhereFieldValues={this.state.receiptWhereFieldValues}
						receiptPackageFieldValues={this.state.receiptPackageFieldValues}
						receiptPhotographersFieldValues={this.state.receiptPhotographersFieldValues}
						link={this.props.link}
						/>
					</div>
				</React.Fragment>
			);

		
	}
}
