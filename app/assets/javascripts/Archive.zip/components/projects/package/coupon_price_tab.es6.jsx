class CouponPriceTab extends React.Component {
  constructor(props) {
        super(props);
        this.state = {
            price_type: '',
            shoot_type_selected_id:'',
            receiveType:'',

        };
        this.handleClickHighPricePackage = this.handleClickHighPricePackage.bind(this);
        this.handleClickLowPricePackage = this.handleClickLowPricePackage.bind(this);
    }
    componentWillReceiveProps(nextProps){

        if(nextProps.shoot_type_selected_id!==this.props.shoot_type_selected_id)
        {

            this.setState({'price_type':''});

        }
        else if(nextProps.receiveType!==this.props.receiveType && nextProps.receiveType=='online-gallery')
        {
            this.setState({'price_type':''});
        }
        else if(nextProps.receiveType!==this.props.receiveType && nextProps.receiveType=='memory-plus')
        {
            this.setState({'price_type':'high'});
        }
        this.setState({'shoot_type_selected_id':nextProps.shoot_type_selected_id});
        this.setState({'receiveType':nextProps.receiveType});

    }
    handleClickHighPricePackage(event){

        this.setState({price_type:'high'});
        this.props.isServiceSelected_callBack3(false);


    }
    handleClickLowPricePackage(event){


        this.setState({price_type:'low'});
        this.props.isServiceSelected_callBack3(false);

    }
    render(){

        if(this.state.shoot_type_selected_id=='')
            return(<div id="price_selection"></div>);
        else if(this.state.receiveType==''){
             return(<div id="price_selection"></div>);
        }
        else if(this.state.receiveType=='memory-plus')
        {
            return (
                <div id='price_selection'>
                    <figure id="sp4" className="pricing ">
                        <h3>۴- انتخاب قیمت</h3>


                            <div className="pricing-section">


                                    <a href="#packages" className={"block "+((this.state.price_type==='high')? 'selected':'')} onClick={this.handleClickHighPricePackage}>

                                            <div className="img-box hidden-xs">
                                                <img src="https://app.kadro.co/img/high-book.png"/>
                                            </div>
                                            <div className="info-box">
                                                <p className="title" style={{textAlign: 'right'}}>
                                                    برای من تعداد عکس مهم است.
                                                </p>
                                                <p className="description" style={{textAlign: 'right'}}>
                                                    همه تصاویر عکاسی شده را دانلود کنید و همه خاطرات رو به یادبسپرید.
                                                </p>
                                            </div>
                                    </a>

                            </div>
                            <div ref="service_packages" className="shoot-package">

                                <PriceSelectionTab mediumImageLink={this.props.mediumImageLink}
                                                 price_type={this.state.price_type}
                                                 shoot_type_selected_id={this.props.shoot_type_selected_id}
                                                 token={this.props.token}
                                                 project_slug={this.props.project_slug}
                                                 selectedServicePackageIdCallBack={this.props.selectedServicePackageIdCallBack}
                                                 low_service_packages={this.props.low_service_packages}
                                                 high_service_packages={this.props.high_service_packages}
                                                 high_length_of_packages={this.props.high_length_of_packages}
                                                 low_length_of_packages={this.props.low_length_of_packages}
                                                 isServiceSelected_callBack1={this.props.isServiceSelected_callBack1}
                                                 servicePackageSelectedData_callBack={this.props.servicePackageSelectedData_callBack}
                                />
                            </div>

                    </figure>
                </div>
            );
        }
        else
        {
            return (
                <div id='price_selection'>
                    <figure id="sp4" className="pricing ">
                        <h3>۴- انتخاب قیمت</h3>


	                        <div className="pricing-section">

			                        <a href="#packages"  className={"block "+((this.state.price_type==='low')? 'selected':'')} onClick={this.handleClickLowPricePackage}
			                             style={{marginLeft: '2%'}}>

				                            <div className="img-box hidden-xs">
				                                <img src="https://app.kadro.co/img/low-book.png"/>
				                            </div>
				                            <div className="info-box">
				                                <p className="title" style={{textAlign: 'right'}}>
				                                    برای من هزینه مهم است.
				                                </p>
				                                <p className="description" style={{textAlign: 'right'}}>
				                                    از بین همه عکس ها تعدادی را رایگان دانلود کنید و
				                                    برای
				                                    هر عکس بیشتر
				                                    ۱۰۰۰۰
				                                    تومان
				                                    پرداخت کنید.
				                                </p>
				                            </div>

			                        </a>


		                            <a href="#packages" className={"block "+((this.state.price_type==='high')? 'selected':'')} onClick={this.handleClickHighPricePackage}>

			                                <div className="img-box hidden-xs">
			                                    <img src="https://app.kadro.co/img/high-book.png"/>
			                                </div>
			                                <div className="info-box">
			                                    <p className="title" style={{textAlign: 'right'}}>
			                                        برای من تعداد عکس مهم است.
			                                    </p>
			                                    <p className="description" style={{textAlign: 'right'}}>
			                                        همه تصاویر عکاسی شده را دانلود کنید و همه خاطرات رو به یادبسپرید.
			                                    </p>
			                                </div>
		                            </a>

	                        </div>
	                        <div ref="service_packages" className="shoot-package">

		                       	<PriceSelectionTab mediumImageLink={this.props.mediumImageLink}
		                                         price_type={this.state.price_type}
		                                         shoot_type_selected_id={this.props.shoot_type_selected_id}
		                                         token={this.props.token}
		                                         project_slug={this.props.project_slug}
                                                 selectedServicePackageIdCallBack={this.props.selectedServicePackageIdCallBack}
		                                         low_service_packages={this.props.low_service_packages}
		                                         high_service_packages={this.props.high_service_packages}
		                                         high_length_of_packages={this.props.high_length_of_packages}
		                                         low_length_of_packages={this.props.low_length_of_packages}
		                                         isServiceSelected_callBack1={this.props.isServiceSelected_callBack1}
						                         servicePackageSelectedData_callBack={this.props.servicePackageSelectedData_callBack}
		                        />
		                  	</div>

                    </figure>
                </div>
            );
        }
    }
}
