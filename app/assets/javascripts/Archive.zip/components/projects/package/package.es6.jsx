
class Package extends React.Component {

	constructor(props) {
        super(props);
        this.state = {
        	selectedType:"hidden",
       		emailAddress: props.email_address,
            firstName: props.first_name,
            lastName: props.last_name,
            mobileNumber: props.mobile_number,
            companyName:"",
            displayCompanyInput:"hidden",
            token:"",
            project_slug:"",
            personal_shoot_types:[],
            business_shoot_types:[],
            isServiceSelected:false,
            error_messages: {},
            shoot_type_selected_id: '',
            price_type: '',
            servicePackageSelectedData:{},
            informationInputsChanged:false,
		};
		this.handleEmailChange = this.handleEmailChange.bind(this);
		this.handleLastNameChange = this.handleLastNameChange.bind(this);
        this.handleMobileNumberChange = this.handleMobileNumberChange.bind(this);
        this.handleFirstNameChange = this.handleFirstNameChange.bind(this);
        this.handleCompanyNameChange = this.handleCompanyNameChange.bind(this);
        this.renderPersonal = this.renderPersonal.bind(this);
        this.renderBusiness = this.renderBusiness.bind(this);
        this.handleDisplayCompanyInput = this.handleDisplayCompanyInput.bind(this);
        this.handleCallShootTypesApi = this.handleCallShootTypesApi.bind(this);
        this.handleSubmitButton = this.handleSubmitButton.bind(this);
        this.saveAndContinue = this.saveAndContinue.bind(this);
        this.handleInformationValidation = this.handleInformationValidation.bind(this);
        this.handleCallUpdateUserApi=this.handleCallUpdateUserApi.bind(this);
    }
    handleEmailChange(event){
        this.setState({emailAddress: event.target.value});
        this.setState({informationInputsChanged: true});

    }
    handleLastNameChange(event){
        this.setState({lastName: event.target.value});
        this.setState({informationInputsChanged: true});

    }
    handleMobileNumberChange(event){
        this.setState({mobileNumber: event.target.value});

    }
    handleFirstNameChange(event){
        this.setState({firstName: event.target.value});
        this.setState({informationInputsChanged: true});

    }
    handleCompanyNameChange(event){
    	this.setState({companyName: event.target.value});
        this.setState({informationInputsChanged: true});

    }
    handleInformationValidation(){

        ///mobile number pattern validation

        $('#mobile_number').parsley().validate();
        $('#email').parsley().validate();
        $('#name').parsley().validate();
        $('#family').parsley().validate();


        if(!$('#mobile_number').parsley().isValid() ||!$('#email').parsley().isValid() || !$('#email').parsley().isValid() || !$('#name').parsley().isValid()|| !$('#family').parsley().isValid())
        {
            formIsValid = false;
        }
        else{
           formIsValid = true;
        }

      	return formIsValid;
    }
    renderBusiness(){
	    if(!this.handleInformationValidation())
            return;

        this.setState({informationInputsChanged: false});

        let target = $('#detail');
        if( target.length ) {
          $('html, body').stop().animate({
              scrollTop: target.offset().top
          }, 1000);
        }

        if(this.state.business_shoot_types.length==0)
            this.handleCallShootTypesApi();

        if(this.state.selectedType=='personal')
        {
            //reset
            this.setState({'shoot_type_selected_id':''});
            this.setState({'isServiceSelected':false});

        }
        this.setState({selectedType:"business"});

    }
    renderPersonal(){

		if(!this.handleInformationValidation())
			return;
        this.setState({informationInputsChanged: false});
        let target = $('#detail');
        if( target.length ) {
          $('html, body').stop().animate({
              scrollTop: target.offset().top
          }, 1000);
        }

		if(this.state.personal_shoot_types.length==0)
            this.handleCallShootTypesApi();

        if(this.state.selectedType=='business')
        {
            //reset
            this.setState({'shoot_type_selected_id':''});
            this.setState({'isServiceSelected':false});

        }
        this.setState({selectedType:"personal"});
    }

    handleDisplayCompanyInput(){
    	this.setState({displayCompanyInput:""});
    }
    handleCallShootTypesApi(){
        // Github fetch library : https://github.com/github/fetch
        // Call the API page
        let personal_shoot_items=[];
        let business_shoot_items=[];
        let body="user[first_name]="+this.state.firstName+"&user[last_name]="+this.state.lastName+"&user[mobile_number]="+this.state.mobileNumber+"&user[email]="+this.state.emailAddress+"&user[company_name]="+this.state.companyName;
        let url=this.props.link+'/api/v1/users/';
        return fetch(url, {method:'post',
            body: body,
            headers: { "Content-Type": "application/x-www-form-urlencoded","Accept":"application/json" }})
            .then((r)=>r.json().then((r2) =>{

                r2['shoot_types'][0].map((item) =>{

                    if(JSON.stringify(item['is_personal'])==='true'){

                        personal_shoot_items.push(item);


                     }
                     else{

                         business_shoot_items.push(item);


                    }
                });

                this.setState({token: r2['token']});
                this.props.token(r2['token']);
                this.setState({project_slug: r2['project_slug']});
                this.props.project_slug(r2['project_slug']);
                this.setState({business_shoot_types: business_shoot_items});
                this.setState({personal_shoot_types: personal_shoot_items});

            }))
            .catch(function(e){console.log(e)});

// Now use it!

    }
    handleCallUpdateUserApi(){
        let body="user[first_name]="+this.state.firstName+"&user[last_name]="+this.state.lastName+"&user[mobile_number]="+this.state.mobileNumber+"&user[email]="+this.state.emailAddress+"&user[company_name]="+this.state.companyName;
        let url=this.props.link+'/api/v1/update_user';
        return fetch(url, {method:'post',
            body: body,
            headers: { "Content-Type": "application/x-www-form-urlencoded","Accept":"application/json" ,"Authorization":this.state.token }})
            .catch(function(e){console.log(e)});
    }
    saveAndContinue(){

        //preparing for receipt page show user and package information
        var data = {

            firstName:this.state.firstName,
            lastName:this.state.lastName,
            mobileNumber:this.state.mobileNumber,
            emailAddress:this.state.emailAddress,
            title:this.state.servicePackageSelectedData.title,
            duration:this.state.servicePackageSelectedData.duration,
            is_full:this.state.servicePackageSelectedData.is_full,
            digitals:this.state.servicePackageSelectedData.digitals,
        }
        this.props.receiptPackageFieldValues(data);


        this.props.selectedServicePackageIdCallBack(this.state.selectedServicePackageId);
        this.props.nextStep();
    }
    handleSubmitButton(){
        if(!this.handleInformationValidation())
        {
            $("html, body").animate({ scrollTop: 0 }, "slow");

            return;
        }
        else if(this.state.informationInputsChanged)
        {
            this.handleCallUpdateUserApi();
            this.setState({informationInputsChanged: false});
        }

    	let error_messages = {};
    	let body="reserve[package_id]="+this.state.selectedServicePackageId+"&project_slug="+this.state.project_slug;

        let url=this.props.link+'/api/v1/submit_package';
        return fetch(url, {method:'post',
            body: body,
            headers: { "Content-Type": "application/x-www-form-urlencoded","Accept":"application/json" ,"Authorization":this.state.token }})
            .then((response)=>{
            	if (parseInt(response.status) !== 202) {
            		response.json().then((object) =>{

                		error_messages["submit_package"] = object.messages;
                		this.setState({error_messages: error_messages});
    				})
            	}
                else{
                    this.saveAndContinue();
                }



            })
            .catch(function(e){console.log(e)});


    }
    componentDidMount(){
        if(this.props.mobile_number !=""){
            $('#mobile_number').prop('readonly', true);
        }


    }
    componentDidUpdate(){
        $('a[href^="#"]').on('click', function(event) {
            var target = $(this.getAttribute('href'));
              if( target.length ) {
                  event.preventDefault();
                  $('html, body').stop().animate({
                      scrollTop: target.offset().top
                  }, 1000);
            }
        });
    }
    render() {
        return (
        	<React.Fragment>
				<div className="container">
					<div className="main">
                        <div className="tracker">
                            <div className="process-tabs-line w-hidden-tiny">
                                <span className="step-line step-line-package" style={{width: "33.3333%", right: "0%"}}></span>
                                <span className="step-line step-line-datetime" style={{width: '33.3333%', right: '33.3333%'}}></span>
                                <span className="step-line step-line-details" style={{width: "33.3333%", right: "66.6667%"}}></span>
                            </div>
                            <div className="process-tab-button tracker-circle selected" style={{right: '0%'}}>
                                <div className="tracker-text">
                                    پکیج
                                </div>
                            </div>
                            <div className="process-tab-button tracker-circle " style={{right: '33.3333%'}}>
                                <div className="tracker-text">
                                    کی و کجا؟
                                </div>
                            </div>
                            <div className="process-tab-button tracker-circle" style={{right: '66.6667%'}}>
                                <div className="tracker-text">
                                    عکاس
                                </div>
                            </div>
                            <div className="process-tab-button tracker-circle" style={{right: '100%'}}>
                                <div className="tracker-text">
                                    جزئیات
                                </div>
                            </div>
                        </div>
                        <div className="wrapper">
							<h3>۱- اطلاعات شما</h3>
							<form novalidate="" className="form form-group" id="package_form" action="/reserve/package" accept-charset="UTF-8" method="post">
		                    	<div className="row" >
		                            <div className="col-sm-6">
		                            	<label htmlFor="name"></label>
		                                <input className="form-control" name="name" id="name" placeholder="نام" required type="text" value={this.state.firstName} onChange={this.handleFirstNameChange}/>

		                            </div>
		                            <div className="col-sm-6">
		                                <label htmlFor="name"></label>
		                                <input className="form-control" name="family" id="family" placeholder="نام خانوادگی" required type="text" value={this.state.lastName} onChange={this.handleLastNameChange}/>

		                            </div>
		                            <div className="col-sm-6">
		                                <label htmlFor="mobile_number"></label>
		                                <input className="form-control" name="mobile_number" id="mobile_number" placeholder="شماره موبایل" required type="number"  data-parsley-pattern="(0|\+98)?([ ]|,|-|[()]){0,2}9[0|1|2|3|4]([ ]|,|-|[()]){0,2}(?:[0-9]([ ]|,|-|[()]){0,2}){8}" value={this.state.mobileNumber} onChange={this.handleMobileNumberChange}/>

		                            </div>
		                            <div className="col-sm-6">
		                                <label htmlFor="email"></label>
		                                <input className="form-control" name="email" id="email" placeholder="ایمیل" required type="email"  value={this.state.emailAddress} onChange={this.handleEmailChange}/>

		                            </div>
		                            <span className={ "add-company "+((this.state.displayCompanyInput==='hidden')? '':'hidden')} onClick={this.handleDisplayCompanyInput}>افزودن نام شرکت</span>
                                    <div className={"col-sm-6 "+(this.state.displayCompanyInput)+" company"}>
                                        <label htmlFor="name"></label>
                                        <input className="form-control" name="company" id="company" placeholder="نام شرکت" type="text" value={this.state.companyName} onChange={this.handleCompanyNameChange}/>

                                    </div>
		                        </div>

		                    </form>
						</div>
						<div className="wrapper" id="ask">
                                <div className="package">
                                    <h3>
                                        ۲-
                                        عکس برای کسب و کارتون می خواهید یا ثبت یک خاطره شخصی؟
                                    </h3>
                                </div>

                                <div className="speciality-type">
                                    <div className={ 'type-box border ' +((this.state.selectedType==='business')? 'selected':'')} value="business" onClick={this.renderBusiness} > کسب و کار</div>
                                    <div className={ 'type-box '+((this.state.selectedType==='personal') ? 'selected': "") } value="personal" onClick={this.renderPersonal}>شخصی</div>
                                </div>
                        </div>
                        <SelectFieldTypeTab
                        selectedType={this.state.selectedType}
                        token={this.state.token}
                        project_slug={this.state.project_slug}
                        business_shoot_types={this.state.business_shoot_types}
                        personal_shoot_types={this.state.personal_shoot_types}
                        selectedServicePackageIdCallBack={(id) => this.setState({selectedServicePackageId:id})}
                        isServiceSelected_callBack1={(id) => this.setState({isServiceSelected:id})} // 3 ja taghir midan dokmeye edame ro
                        isServiceSelected_callBack2={(id) => this.setState({isServiceSelected:id})}
                        isServiceSelected_callBack3={(id) => this.setState({isServiceSelected:id})}
                        shoot_type_selected_title_callBack={this.props.shoot_type_selected_title_callBack}
                        shoot_type_selected_id_callBack1={this.props.shoot_type_selected_id_callBack1}
                        shoot_type_selected_id_callBack2={(id) => this.setState({shoot_type_selected_id:id})}//vase inke age taghir dad type ro baghiye taghir konan
                        shoot_type_selected_id={this.state.shoot_type_selected_id}
                        servicePackageSelectedData_callBack={(id) => this.setState({servicePackageSelectedData:id})}
                        link={this.props.link}
                        />
                        <span style={{color: 'red'}}>{this.state.error_messages["submit_package"]}</span>
                    </div>


	            </div>
                <footer id="footer">
                    <div className="container">
                        <div className="wrap">
                            <a className="btn btn-gray" href={(this.props.link)+"/"} >بازگشت</a>
                            <button type="submit" id="submit_page_form" className="btn btn-blue" onClick={this.handleSubmitButton} disabled={ !this.state.isServiceSelected }>ذخیره و ادامه
                            </button>

                        </div>
                    </div>
                </footer>

	        </React.Fragment>
        );
    }
}
