class PriceSelectionTab extends React.Component {
	constructor(props) {
        super(props);
        this.state = {
            shoot_type_selected_id: '',
            service_packages:[],
        };
    }
    componentWillReceiveProps(nextProps){

        if(nextProps.shoot_type_selected_id!==this.props.shoot_type_selected_id)
        {

            this.setState({'receiveType':''});

        }
        this.setState({'shoot_type_selected_id':nextProps.shoot_type_selected_id});
        this.setState({'receiveType':nextProps.receiveType});

    }
  	render()
	{
        if(this.props.receiveType=="memory-plus"){

	        return(
	            <div id="packages">
	                <h3 style={{textAlign:'right'}}>۴- برای چند ساعت عکاس می خواهید؟</h3>
	                <ServicePackagesTab
                        mediumImageLink={this.props.mediumImageLink}
                        token={this.props.token}
                        project_slug={this.props.project_slug}
                        shoot_type_selected_id={this.props.shoot_type_selected_id}
                        service_packages={this.props.memoryPlusOrderedPackages}
						length_of_packages={this.props.memoryPlusOrderedPackagesLength}
                        selectedServicePackageIdCallBack={this.props.selectedServicePackageIdCallBack}
                        isServiceSelected_callBack1={this.props.isServiceSelected_callBack1}
                        hours={this.props.memoryHours}
                        ticks={this.props.memoryTicks}
                        receiveType={this.props.receiveType}
                        servicePackageSelectedData_callBack={this.props.servicePackageSelectedData_callBack}
                        link={this.props.link}
                    />
	            </div>

	        );
	    }
	    else if (this.props.receiveType=="online-gallery"){

	        return(
	            <div id="packages">
	                <h3>۴- برای چند ساعت عکاس می خواهید؟</h3>
	                <ServicePackagesTab
                        mediumImageLink={this.props.mediumImageLink}
                        token={this.props.token}
                        project_slug={this.props.project_slug}
                        shoot_type_selected_id={this.props.shoot_type_selected_id}
                        service_packages={this.props.privateGalleryOrderedPackages}
                        length_of_packages={this.props.privateGalleryOrderedPackagesLength}
                        isServiceSelected_callBack1={this.props.isServiceSelected_callBack1}
                        selectedServicePackageIdCallBack={this.props.selectedServicePackageIdCallBack}
                        receiveType={this.props.receiveType}
                        servicePackageSelectedData_callBack={this.props.servicePackageSelectedData_callBack}
                        link={this.props.link}
                        hours={this.props.galleryHours}
                        ticks={this.props.galleryTicks}
                    />
	            </div>

	        );
	    }
	    else{
	        return <div id='packages'></div>;
	    }
	}
}
