class ReceiveTypeTab extends React.Component {
	constructor(props) {
        super(props);
        this.state = {
            receiveType: '',
            shoot_type_selected_id:'',
            deliveryAtLocation:'',
        };
        this.handleClickMemoryPlus = this.handleClickMemoryPlus.bind(this);
        this.handleClickOnlineGallery = this.handleClickOnlineGallery.bind(this);
        //this.handleCallSubmitDeliveryAtLocationApi = this.handleCallSubmitDeliveryAtLocationApi.bind(this);
    }
    componentWillReceiveProps(nextProps){

        if(nextProps.shoot_type_selected_id!==this.props.shoot_type_selected_id)
        {


            this.setState({'receiveType':''});

        }
        this.setState({'shoot_type_selected_id':nextProps.shoot_type_selected_id});

    }
    handleClickMemoryPlus(event){

        this.setState({receiveType:'memory-plus'});
        this.props.isServiceSelected_callBack3(false);
        this.setState({deliveryAtLocation:'true'},()=>{
        	this.handleCallSubmitDeliveryAtLocationApi();
        });



    }
    handleClickOnlineGallery(event){

        this.setState({receiveType:'online-gallery'});
        this.props.isServiceSelected_callBack3(false);
        this.setState({deliveryAtLocation:'false'},()=>{
        	this.handleCallSubmitDeliveryAtLocationApi();
        });


    }
    handleCallSubmitDeliveryAtLocationApi(){

        let body="reserve[delivery_at_location]="+this.state.deliveryAtLocation+"&project_slug="+this.props.project_slug;
        let url=this.props.link+'/api/v1/submit_delivery_at_location';
        return fetch(url, {method:'post',
            body: body,
            headers: { "Content-Type": "application/x-www-form-urlencoded","Accept":"application/json" ,"Authorization":this.props.token }})
            .catch(function(e){console.log(e)});


    }
	render(){

		if(this.state.shoot_type_selected_id=='')
            return(<div className="pricing" id="receive-type"></div>);
        else
        {
			return(
				<React.Fragment>
					<div className="pricing" id="receive-type">
	                    <h3>
	                    ۳-
                      انتخاب نحوه دریافت عکس ها
	                    </h3>
	                    <div className="pricing-section" id="delivery-section" style={{marginBottom: '2%'}}>
	                        <a href='#price_selection' id="online-gallery" className={"block "+((this.state.receiveType==='online-gallery')? 'selected':'')} onClick={this.handleClickOnlineGallery} style={{marginLeft:'2%'}}>
	                            <div className="img-box hidden-xs">
	                                <img src="/img/album.png" />
	                            </div>
	                            <div className="info-box">
	                                <p className="title"  style={{textAlign: 'right'}}>
	                                گالری خصوصی آنلاین
	                                </p>
	                                <p className="description"  style={{textAlign: 'right'}}>
                                  *
                                  عکس ها را تا ۷۲ ساعت بعد از گالری خصوصی امن دریافت کنید.
	                                <br />
                                  <strong style={{color:'#328AF6'}}>
                                  *
                                  شامل ادیت نور و رنگ استاندارد.
                                  </strong>
	                                </p>
	                            </div>
	                        </a>
	                        <a href='#price_selection' id="memory-plus" className={"block "+((this.state.receiveType==='memory-plus')? 'selected':'')} onClick={this.handleClickMemoryPlus}>
	                            <div className="img-box hidden-xs">
	                                <img src="/img/memory-plus.png" />
	                            </div>
	                            <div className="info-box">
	                                <p className="title"  style={{textAlign: 'right'}}>
	                                سرویس مموری پلاس
	                                </p>
	                                <p className="description" style={{textAlign: 'right'}}>
                                  *
                                  عکس ها را در محل دریافت کنید.
	                                <br />
                                  <strong style={{color:'#328AF6'}}>
                                  *
                                  امکان حذف همه عکسها از حافظه دوربین عکاس.
                                  </strong>
	                                </p>
	                            </div>
	                        </a>
	                    </div>
	                </div>
					<div id='price_selection'>
						<figure id="sp4" className="pricing ">
							<div ref="service_packages" className="shoot-package">
								<PriceSelectionTab
				                    mediumImageLink={this.props.mediumImageLink}
				                    shoot_type_selected_id={this.props.shoot_type_selected_id}
				                    token={this.props.token}
				                    project_slug={this.props.project_slug}
				                    selectedServicePackageIdCallBack={this.props.selectedServicePackageIdCallBack}
				                    isServiceSelected_callBack1={this.props.isServiceSelected_callBack1}
				                    isServiceSelected_callBack3={this.props.isServiceSelected_callBack3}
				                    galleryHours={this.props.galleryHours}
				                    memoryHours={this.props.memoryHours}
				                    galleryTicks={this.props.galleryTicks}
				                    memoryTicks={this.props.memoryTicks}
				                    receiveType={this.state.receiveType}
				                    memoryPlusOrderedPackages={this.props.memoryPlusOrderedPackages}
				                    privateGalleryOrderedPackages={this.props.privateGalleryOrderedPackages}
				                    memoryPlusOrderedPackagesLength={this.props.memoryPlusOrderedPackagesLength}
				                    privateGalleryOrderedPackagesLength={this.props.privateGalleryOrderedPackagesLength}
				                    servicePackageSelectedData_callBack={this.props.servicePackageSelectedData_callBack}
				                    receiveType={this.state.receiveType}
				                    link={this.props.link}
				                    />
				                    </div>
	                    </figure>
                	</div>
				</React.Fragment>
			);
		}
	}
}
