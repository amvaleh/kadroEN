 class SelectFieldTypeTab extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            shoot_type_selected_id: '',
        };
    }
    componentWillReceiveProps(nextProps){
        if(nextProps.shoot_type_selected_id!==this.props.shoot_type_selected_id)
        {    
            this.setState({'shoot_type_selected_id':nextProps.shoot_type_selected_id});

        }
        
    
    }
    render(){
    	
        if(this.props.selectedType=="business"){

            return(
                
                	<ShootTypesTab 
                    token={this.props.token} 
                    project_slug={this.props.project_slug} 
                    shoot_types={this.props.business_shoot_types}  
                    selectedServicePackageIdCallBack={this.props.selectedServicePackageIdCallBack}
                    isServiceSelected_callBack1={this.props.isServiceSelected_callBack1} 
                    isServiceSelected_callBack2={this.props.isServiceSelected_callBack2}
                    isServiceSelected_callBack3={this.props.isServiceSelected_callBack3}
                    shoot_type_selected_title_callBack={this.props.shoot_type_selected_title_callBack}
                    shoot_type_selected_id_callBack1={this.props.shoot_type_selected_id_callBack1}
                    shoot_type_selected_id_callBack2={this.props.shoot_type_selected_id_callBack2}
                    shoot_type_selected_id={this.state.shoot_type_selected_id}
                    servicePackageSelectedData_callBack={this.props.servicePackageSelectedData_callBack}
                    link={this.props.link}
                    />
                
            );
        }
        else if (this.props.selectedType=="personal"){
        	
            return(
                
                	<ShootTypesTab 
                    token={this.props.token} 
                    project_slug={this.props.project_slug} 
                    shoot_types={this.props.personal_shoot_types} 
                    selectedServicePackageIdCallBack={this.props.selectedServicePackageIdCallBack} 
                    isServiceSelected_callBack1={this.props.isServiceSelected_callBack1} 
                    isServiceSelected_callBack2={this.props.isServiceSelected_callBack2} 
                    isServiceSelected_callBack3={this.props.isServiceSelected_callBack3}
                    shoot_type_selected_title_callBack={this.props.shoot_type_selected_title_callBack}
                    shoot_type_selected_id_callBack1={this.props.shoot_type_selected_id_callBack1}
                    shoot_type_selected_id_callBack2={this.props.shoot_type_selected_id_callBack2}
                    shoot_type_selected_id={this.state.shoot_type_selected_id}
                    servicePackageSelectedData_callBack={this.props.servicePackageSelectedData_callBack}
                    link={this.props.link}
                    />
            	
            );
        }
        else{
            return(

                <div id="detail">
                </div>
            );
        }
    }
}
