class ServicePackagesTab extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      servicePackageSelectedId: '',
      isServiceSelected:false,
      servicePackageSelectedIndex:-1,
      hourSelectedIndex:0,
      hourSelectedPackages:[],

    };

    this.handleClickServicePackage=this.handleClickServicePackage.bind(this);

    this.getServicePackagesFromHourSelectedIndex=this.getServicePackagesFromHourSelectedIndex.bind(this);
    this.setServicePackageInformationsFromId=this.setServicePackageInformationsFromId.bind(this);
  }
  getServicePackagesFromHourSelectedIndex(index){
    // this.state.selectedServicePackageIndex -> this.state.selectedServicePackageId

    let resultPackages=[];
    this.props.service_packages
    .map((object)=>{

      object.map((item,i)=>{
        if(i==index)
        {

          //preparing for receipt page show package informations
          resultPackages.push(item);

        }
      })
    });

    return resultPackages;
  }
  setServicePackageInformationsFromId(id){
    let returnPackageId='';
    this.props.service_packages
    .map((item)=>{
      if(id==item['id'])
      {
        returnPackageId=item['id'];
        var data={
          title:item['title'],
          duration:item['duration'],
          is_full:item['is_full'],
          digitals:item['digitals'],
        }
        this.props.servicePackageSelectedData_callBack(data);
      }
    });
  }
  handleClickServicePackage(event)
  {


    this.setState({servicePackageSelectedIndex: parseInt(event.currentTarget.getAttribute('index')) });
    this.setState(
      {servicePackageSelectedId: event.currentTarget.getAttribute('data-value')}, () =>
      {

        this.props.selectedServicePackageIdCallBack(this.state.servicePackageSelectedId);
        this.setServicePackageInformationsFromId(this.state.servicePackageSelectedId);
      }
    );
    this.setState(
      {isServiceSelected: true}, () =>
      {

        this.props.isServiceSelected_callBack1(this.state.isServiceSelected);

      }
    );


  }

  componentDidMount(){

    $(".service_package").css("display","none");

    $( "div[hourindex="+(this.state.hourSelectedIndex)+"]" ).css("display","");

    let Slider=$("#ex6");
    Slider.slider();
    Slider.on("change", (slideEvt)=> {
      let slider_value=slideEvt.value;
      this.setState({hourSelectedIndex: slider_value.newValue });

      this.setState({servicePackageSelectedIndex: -1 });

      this.setState(
        {isServiceSelected: false}, () =>
        {

          this.props.isServiceSelected_callBack1(this.state.isServiceSelected);

        }
      );

    });
  }
  componentWillReceiveProps(nextProps){

    if(nextProps.receiveType!==this.props.receiveType)
    {
      this.setState({servicePackageSelectedIndex:-1});
      $("#ex6").slider('destroy');
      $("#ex6").slider();
      $("#ex6").slider('setValue', '-1', true);
      $("#ex6").on("change", (slideEvt)=> {
        let slider_value=slideEvt.value;
        this.setState({servicePackageSelectedIndex: -1 });
        this.setState({hourSelectedIndex: slider_value.newValue });

        this.setState(
          {isServiceSelected: false}, () =>
          {

            this.props.isServiceSelected_callBack1(this.state.isServiceSelected);

          }
        );
      });
    }


  }
  componentDidUpdate(){

    $(".service_package").css("display", "none");

    $( "div[hourindex="+(this.state.hourSelectedIndex)+"]" ).css("display", "");
  }
  render(){
    let tempSelectedPackageIndex='';
    let sliderBarWidth=(180*(this.props.length_of_packages-1));

    //convert English Digits to Persian Digits
    let persianDigits = "۰۱۲۳۴۵۶۷۸۹";
    let persianMap = persianDigits.split("");
    let icon_url = ""
    let packageItems= this.props.service_packages
    .map((object,i)=>{
      return (
        object.map((item,j)=>{
          if (j==0)
          {
            icon_url = "/img/low-book.png"
          }
          if(j==1){
            icon_url = "/img/high-book.png"
          }
          return (
            <div
            className={"block service_package "+((this.state.servicePackageSelectedIndex===j)? 'selected':'')}
            hourindex={i}
            index={j}
            data-value={item['id']}
            onClick={this.handleClickServicePackage}
            title={item['title']}
            duration={item['duration']}
            is-full={item['is_full']}
            digitals={item['digitals']}
            style={{marginTop: '5%',fontFamily: "iranyekan"}}
            >
            {/*<div className="service-name">
            <p className="service-name-box">
            {item['duration']}
            </p>
            </div>*/}
            <div className="img-box" style={{ backgroundImage: "url("+icon_url+")",height: "100px",width: "160px","background-position": "center","background-size":"75px","background-repeat": "no-repeat"}}>
            </div>
            <div className="info-box" style={{textAlign:'right'}}>
            <p className="title">
            <a className="price">{item['price'].toString().replace(/\d/g, function (m) {
              return persianMap[parseInt(m)];
            })}


            <small> تومان </small>
            </a>
            </p>
            <p className="description " style={{fontSize: '14px',
            textAlign: 'right',
            marginTop: '15px',}}>
            با ادیت نور و رنگ حرفه ای
            </p>

            <p className="description " style={{fontSize: '14px',
            textAlign: 'right',
            marginTop: '15px',
          }}>
          {item['description']}
          </p>
          </div>
          </div>
        );
      })
    );

  });


  return(
    <div>

    <input id="ex6" type="text"
    className="shoot hidden-xs hidden-sm"
    data-slider-min="0"
    data-slider-max={this.props.length_of_packages-1}
    data-slider-step="1"
    data-slider-value={this.state.hourSelectedIndex}
    data-slider-tooltip="hide"
    data-interval="500"
    data-slider-ticks={this.props.ticks}
    data-slider-ticks-labels={this.props.hours}
    style={{width: ((sliderBarWidth<992)?sliderBarWidth:991) , marginRight: 'auto' , marginLeft: 'auto' , display: 'none'}}
    />

    <div className="shoot-packages-boxes" style={{marginBottom: '100px'}}>
    <ul id='packs'>
    {packageItems}
    </ul>
    </div>

    <hr />
    <p>
    *
    مدت زمان رزرو عکاس شامل زمان مسیر تا محل پروژه نمی شود، اما شامل زمان مورد نیاز
    برای
    <strong style={{color:'#328AF6'}}>
    راه اندازی و نصب تجهیزات عکاسی

     </strong>
    در محل می شود.
    </p>
    <p>
    *
    در صورت نیاز می توانید
    به صورت ساعتی
    تمدید
    کنید که هزینه هر نیم ساعت تمدید
    ۷۰.۰۰۰
    تومان است.
    </p>
    <p>
    *
    ما به شما فایل اصلی عکس را می دهیم.
    </p>

    </div>

  );
}
}
