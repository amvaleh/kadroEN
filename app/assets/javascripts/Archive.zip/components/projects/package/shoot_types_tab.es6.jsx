class ShootTypesTab extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            shoot_type_selected_id: '',
            mediumImageLink:'',
            more_clicked:false,
            service_packages:[],
            receiveType: '',
            privateGalleryOrderedPackages:[],
            memoryPlusOrderedPackages:[],
            galleryHours:[],
            memoryHours:[],
            galleryTicks:[],
            memoryTicks:[],
                    };
        this.handleClickShootType=this.handleClickShootType.bind(this);
        this.handleClickMoreShootTypes=this.handleClickMoreShootTypes.bind(this);
        this.submitShootCallApi=this.submitShootCallApi.bind(this);
    }
    componentWillReceiveProps(nextProps){

       
        if(nextProps.shoot_type_selected_id!==this.props.shoot_type_selected_id)
        {

            this.setState({'shoot_type_selected_id':nextProps.shoot_type_selected_id});
            this.setState({'receiveType':nextProps.receiveType});

        }
        else{

            this.setState({'receiveType':nextProps.receiveType});
        }

    }

    handleClickShootType(event){
        this.setState({'receiveType':''});
        this.props.isServiceSelected_callBack2(false);
        this.setState({mediumImageLink: event.currentTarget.getAttribute('data-value')});
        this.props.shoot_type_selected_title_callBack(event.currentTarget.getAttribute("data-title"));
        this.setState({shoot_type_selected_id: event.currentTarget.getAttribute("data-id")},()=>{
            this.props.shoot_type_selected_id_callBack1(this.state.shoot_type_selected_id);//be main
            this.props.shoot_type_selected_id_callBack2(this.state.shoot_type_selected_id);//be package
            this.submitShootCallApi();
        });


    }
    handleClickMoreShootTypes(){
    	this.setState({'more_clicked': true});
    }
    submitShootCallApi(){
        let privateGalleryOrderedPackages=[];
        let memoryPlusOrderedPackages=[];
        let lastPackage={};
        let galleryHours=[];
        let memoryHours=[];
        let galleryTicks=[];
        let memoryTicks=[];
        let hourCounter=0;
        let thisHourGalleryPackages=[];
        let thisHourMemoryPackages=[];
        let thisHourNumberGalleryPushed=false;
        let thisHourNumberMemoryPushed=false;
        //convert English Digits to Persian Digits
        let persianDigits = "۰۱۲۳۴۵۶۷۸۹";
        let persianMap = persianDigits.split("");   


        let body="shoot_type[id]="+this.state.shoot_type_selected_id+"&project_slug="+this.props.project_slug;

        let url=this.props.link+'/api/v1/submit_shoot_type';
        return fetch(url, {method:'post',
            body: body,
            headers: { "Content-Type": "application/x-www-form-urlencoded","Accept":"application/json" ,"Authorization":this.props.token }})
            .then((r)=>r.json().then((r2) =>{
                r2['packages'][0].sort((a, b) => a['order'] > b['order'] )
                    .map((item,i) =>{
                        if(Object.keys(lastPackage).length != 0)
                        {   
                            if( lastPackage['order']!=item['order'])
                            {

                                privateGalleryOrderedPackages.push(thisHourGalleryPackages);
                                memoryPlusOrderedPackages.push(thisHourMemoryPackages);
                                thisHourGalleryPackages=[];
                                thisHourMemoryPackages=[];
                                thisHourNumberGalleryPushed=false;
                                thisHourNumberMemoryPushed=false;

                                hourCounter++;
                            }
                        }
                        if(JSON.stringify(item['is_full'])==='true')
                        {
                            item['description']='دانلود همه عکس ها'
                            thisHourMemoryPackages.push(item);
                            
                            
                            if(!thisHourNumberGalleryPushed)
                            {
                                galleryHours.push(item['order'].toString().replace(/\d/g, function (m) {
                                                return persianMap[parseInt(m)];
                                            })+" ساعت ");
                                galleryTicks.push(hourCounter);
                                thisHourNumberGalleryPushed=true;
                                
                            }
                            if(!thisHourNumberMemoryPushed)
                            {
                                memoryHours.push(item['order'].toString().replace(/\d/g, function (m) {
                                                return persianMap[parseInt(m)];
                                            })+" ساعت ");
                                memoryTicks.push(hourCounter);
                                thisHourNumberMemoryPushed=true;
                            }

                        }
                        else{
                            item['description']="دانلود "+
                                    (item['digitals'].toString().replace(/\d/g, function (m) {
                                                return persianMap[parseInt(m)];
                                            }))+" فایل از بین همه عکس ها (هر اضافی "+
                                    (item['extra_price'].toString().replace(/\d/g, function (m) {
                                        return persianMap[parseInt(m)];
                                    }))+
                                    " تومان)";
                            if(!thisHourNumberGalleryPushed)
                            {
                                galleryHours.push(item['order'].toString().replace(/\d/g, function (m) {
                                                return persianMap[parseInt(m)];
                                            })+" ساعت ");
                                galleryTicks.push(hourCounter);
                                thisHourNumberGalleryPushed=true;
                            }
                        } 

                        

                        thisHourGalleryPackages.push(item);
                        lastPackage=item;
                        
                });

                privateGalleryOrderedPackages.push(thisHourGalleryPackages);

                memoryPlusOrderedPackages.push(thisHourMemoryPackages);
                
                this.setState({privateGalleryOrderedPackages: privateGalleryOrderedPackages});
                this.setState({memoryPlusOrderedPackages: memoryPlusOrderedPackages});
                this.setState({galleryHours: JSON.stringify(galleryHours)});
                this.setState({memoryHours: JSON.stringify(memoryHours)});
                this.setState({galleryTicks: JSON.stringify(galleryTicks)});
                this.setState({memoryTicks: JSON.stringify(memoryTicks)});

            }))
            .catch(function(e){console.log(e)});
    }
    render() {

        let shootItems= this.props.shoot_types
        	.sort((a, b) => parseInt(a['order']) < parseInt(b['order']) )
        	.map((item,i) =>
        	{

        		if(this.state.more_clicked === false && i<4)
        		{
        			return(

	                    <li className="col-xs-6 col-sm-4 col-md-3">
	                    	<a href="#receive-type">
		                        <div
                                className={"specialty "+((this.state.shoot_type_selected_id===JSON.stringify(item['id']))? 'selected':'')}
                                data-id={item['id']}
                                data-value={item['avatar']['medium']['url']}
                                data-title={item['title']}
                                onClick={this.handleClickShootType}
                                >
		                            <img src={this.props.link+item['avatar']['url']} alt=""/>
		                            <span>
		                            	{item['title']}
		                        	</span>

		                        </div>
	                        </a>
	                    </li>
	                 );
        		}
        		else if(this.state.more_clicked === true){
        			return(

	                    <li className="col-xs-6 col-sm-4 col-md-3">
	                    	<a href="#receive-type">
		                        <div
                                className={"specialty "+((this.state.shoot_type_selected_id===JSON.stringify(item['id']))? 'selected':'')}
                                data-id={item['id']}
                                data-value={item['avatar']['medium']['url']}
                                data-title={item['title']}
                                onClick={this.handleClickShootType}
                                >
		                            <img src={this.props.link+item['avatar']['url']} alt=""/>
		                            <span>
		                            	{item['title']}
		                        	</span>

		                        </div>
	                       	</a>
	                    </li>
	                 );
        		}





            }
        );

        return (
            <React.Fragment>

                <div className="wrapper" id="detail" >
                    <div id="specialities" className="specialties">
                        <br />
                        <ul className="row row-m10">
                            {shootItems}
                        </ul>
                        <div className="show-more" style={{display: (this.state.more_clicked ? 'none' : 'block')}} onClick={this.handleClickMoreShootTypes}>
                            <span>تخصص بیشتر</span>
                        </div>
                    </div>
                    <ReceiveTypeTab
                    mediumImageLink={this.state.mediumImageLink}
                    shoot_type_selected_id={this.state.shoot_type_selected_id}
                    token={this.props.token}
                    project_slug={this.props.project_slug}
                    selectedServicePackageIdCallBack={this.props.selectedServicePackageIdCallBack}
                    isServiceSelected_callBack1={this.props.isServiceSelected_callBack1}
                    isServiceSelected_callBack3={this.props.isServiceSelected_callBack3}
                    memoryPlusOrderedPackages={this.state.memoryPlusOrderedPackages}
                    privateGalleryOrderedPackages={this.state.privateGalleryOrderedPackages}
                    memoryPlusOrderedPackagesLength={this.state.memoryPlusOrderedPackages.length}
                    privateGalleryOrderedPackagesLength={this.state.privateGalleryOrderedPackages.length}
                    galleryHours={this.state.galleryHours}
                    memoryHours={this.state.memoryHours}
                    galleryTicks={this.state.galleryTicks}
                    memoryTicks={this.state.memoryTicks}
                    receiveType={this.state.receiveType}
                    servicePackageSelectedData_callBack={this.props.servicePackageSelectedData_callBack}
                    link={this.props.link}
                    
                    />

                </div>
            </React.Fragment>
        );
    }
}
