class PhotographerPhotos extends React.Component {
	constructor() {
			super();
			this.state = {
				photographerId: null,
				displayPhotos:false,
			};
	}
	componentDidUpdate(){
	
		$('.portfolio').owlCarousel({
		    items        : 1,
		    navText      : [],
		    margin       : 0,
		    smartSpeed   : 150,
		    loop         : true,
		    nav          : true,
		    autoplay     : true,
		    rtl          : true,
		    autoplaySpeed: 500
		});
		
		
	}
	componentWillReceiveProps(nextProps){

		$('.portfolio').owlCarousel('destroy');
		if(nextProps.displayPhotos !== this.props.displayPhotos)
        {
        	this.setState({displayPhotos: nextProps.displayPhotos});
        	this.setState({photographerId:nextProps.photographerId});
        	
		}
	}
	render(){
			
			if(this.state.displayPhotos)
			{
				let photoItems=this.props.photographersPhotos[this.state.photographerId].map((item) =>
				{
				
					return(
						<div className="item">
							
							<img src={item.file.large.url} alt=""/>
							
						</div>

					);
				});
				
				return(
					<section id="portfolios" className="open">
						<div className="inner">
							<span className="btn close">بستن</span>
							<div className="portfolio owl-carousel">
								{photoItems}
							</div>
						</div>
					</section>
				);
				
			}
			else{
				
				return(<div></div>);
				
			}
				
		
	}	
}