class Photographers extends React.Component {
	constructor() {
			super();
			this.state = {
				isPhotographerSelected:false,
				photographerSelectedId:'',
				availablePhotographers:[],
				photographerPhotos: [],
				photographerSelectedFirstName:'',
				photographerSelectedLastName:'',
				photographerId:null,
				displayPhotos:false,
			};
			this.handleSubmitButton=this.handleSubmitButton.bind(this);
			this.handleClickShowSamplePhotos=this.handleClickShowSamplePhotos.bind(this);
			this.handlePhotographerSelected=this.handlePhotographerSelected.bind(this);
			this.callSubmitPhotographer=this.callSubmitPhotographer.bind(this);
	}
	componentDidUpdate(){

		$('.shoot-slider').owlCarousel({
		  navText        : [],
		  nav            : true,
		  rtl            : true,
		  responsiveClass: true, 
		  responsive     : {
		    0   : {
		      items : 1
		    },
		    600 : {
		      items : 3
		    },
		    1000: {
		      items : 3
		    }
		  }
		});	
		let portfolios = $('#portfolios');

	    portfolios.find('.close').on('click', ()=> {
	      $('#main').removeClass('blur');
	      $('.portfolio').owlCarousel('destroy');
	      this.setState({photographerId: null});
	      this.setState({displayPhotos: false});
	    });


	    jQuery(document).keyup((e)=> {
	      if (e.keyCode === 27) {
	        $('#main').removeClass('blur');
	        $('.portfolio').owlCarousel('destroy');
	        this.setState({photographerId: null});
	        this.setState({displayPhotos: false});
	        
	      }
	    });
		
	    
	}
	componentWillReceiveProps(nextProps){
		
		$('.shoot-slider').owlCarousel('destroy');
        if(nextProps.dateTimeSelected !== this.props.dateTimeSelected)
        {
        	this.setState({isPhotographerSelected:false});
        	$('button.choice').html('انتخاب');
			$('#photographer').find('.item').removeClass('selected');
        }

        
    }
	handleSubmitButton(){
		this.callSubmitPhotographer();
		this.props.nextStep();
		this.props.photographerSelectedId(this.state.photographerSelectedId);

		//preparing for receipt page show photographer infos
		var data={
			firstName:this.state.photographerSelectedFirstName,
			lastName:this.state.photographerSelectedLastName,
		}
		this.props.receiptPhotographersFieldValues(data);
	}
	handleClickShowSamplePhotos(event){
		$('#main').addClass('blur');
		this.setState({displayPhotos: true});
	    this.setState({photographerId:event.currentTarget.getAttribute('data-value')});
	}
	handlePhotographerSelected(event){
		this.setState({isPhotographerSelected:true});
		$('button.choice').html('انتخاب');
		$('#photographer').find('.item').removeClass('selected');
		let $e = $(event.currentTarget);
		$e.html('انتخاب شد');
		$e.parent().addClass('selected');
		this.setState({photographerSelectedId:$e.attr('data-selector')});
		this.setState({photographerSelectedFirstName:$e.attr('first-name')});
		this.setState({photographerSelectedLastName:$e.attr('last-name')});
	}
	callSubmitPhotographer(){
		let feedbacks=[];
		let url=this.props.link+"/api/v1/submit_photographer";
		let body="photographer[id]="+this.state.photographerSelectedId+"&project_slug="+this.props.project_slug;
		fetch(url, {method:'post',
            body: body,
            headers: { "Content-Type": "application/x-www-form-urlencoded","Accept":"application/json" ,"Authorization":this.props.token }})
            .then((response)=>{
            	if (parseInt(response.status) != 202) {
            		response.json().then((object) =>{
            			console.log("response error:"+object);
                		
    				});
    			
            	}
                else{
                	
                	response.json().then((object) =>{
                		object['feedback'][0].map((item) =>{

            				feedbacks.push(item);
            			});
            			this.props.feedbacks(feedbacks);
            		});
						                		
    			}	
					                		
							                		
						                         		
				}).catch(function(e){console.log(e)});
	}
  	render () {
	  	let availablePhotographerItems= this.props.availablePhotographers
		    	.map((item,i) =>
		    	{
					return(
					
		                <div className="item" key={i}>
							<header>
								<a href={'http://'+(item.uid)+'.kadro.co'} target="_blank"><div className="profile">{item.first_name} {item.last_name}</div></a>
							</header>
							<div className="img" style={{backgroundImage: 'url('+(item.avatar.medium.url)+')'}}>
							</div>
							<div className="stars rating">
								<span className="star"></span>
								<span className="star"></span>
								<span className="star"></span>
								<span className="star"></span>
								<span className="star"></span>
							</div>
							<p>
							{"متخصص در عکاسی "+
							(this.props.shootTypeSelectedTitle)}
							</p>
							<button 
							className="portfolio-example btn btn-sm btn-default" 
							data-value={item.id} 
							onClick={this.handleClickShowSamplePhotos}
							style={{marginLeft: "1em"}}
							>
							نمونه کارها
							</button>
							<button 
							className="btn btn-blue choice"  
							first-name={item.first_name} 
							last-name={item.last_name} 
							data-selector={item.id} 
							onClick={this.handlePhotographerSelected}>
							انتخاب
							</button>
						</div>
		             );
		        });
	
		
		if(this.props.availablePhotographers.length>0)
		{
		    return (
		    	
		    	<React.Fragment>
					<section id="main">
						<div className="container">
							<div className="main">
								<div className="tracker">
									<div className="process-tabs-line w-hidden-tiny">
										<span className="step-line step-line-package active" style={{width: '33.3333%', right: '0%'}}></span>
										<span className="step-line step-line-datetime active " style={{width: '33.3333%', right: '33.3333%'}}></span>
										<span className="step-line step-line-details" style={{width: '33.3333%', right: '66.6667%'}}></span>
									</div>

									<div className="process-tab-button tracker-circle selected" style={{right: '0%'}}>
					          			<div className="tracker-text">
					            		پکیج
					          			</div>
					        		</div>
							        <div className="process-tab-button tracker-circle selected" style={{right: '33.3333%'}}>
							          <div className="tracker-text">
							            کی و کجا؟
							          </div>
							        </div>
							        <div className="process-tab-button tracker-circle selected" style={{right: '66.6667%'}}>
			                            <div className="tracker-text">
			                                عکاس
			                            </div>
			                    	</div>
			                        <div className="process-tab-button tracker-circle" style={{right: '100%'}}>
			                            <div className="tracker-text">
			                                جزئیات
			                            </div>
			                        </div>
								</div>
								<div className="wrapper">
							        <div id="photographer">
										<h3>
										عکاسی را که دوست دارید انتخاب کنید:
										</h3>
										<p>
										این عکاسان بهترین گزینه ها با توجه به زمان و مکان و مشخصات
										عکاسی مورد نیاز شما هستند.
										</p>
										<div className="shoot-slider owl-carousel">
										 {/*if direct_reserve and photographer has the expertises for this shoot type*/ }
				            			{ /*quering through photographers*/} 
				            				
	        							{availablePhotographerItems}
											
										</div>
	        							
			        				</div>
			        			
			        			</div>
			        			<input type="hidden" name="project_id" id="project_id" value="" />
			        			<input type="hidden" name="photographer" id="shooter" value="" />
			    			</div>
			  			</div>
						<footer id="footer">
			                <div className="container">
			                    <div className="wrap">
			                        <a className="btn btn-gray" onClick={this.props.previousStep} >بازگشت</a>
			                        <button type="submit" id="submit_page_form" className="btn btn-blue" onClick={this.handleSubmitButton} disabled={!this.state.isPhotographerSelected } >ذخیره و ادامه
			                        </button>
			                    </div>
			                </div>
		            	</footer>
					</section>
					<PhotographerPhotos 
						photographerId={this.state.photographerId}
						photographersPhotos={this.props.photographersPhotos}
						displayPhotos={this.state.displayPhotos}
					/>
		        </React.Fragment>
		    );
		}
		else{
			return(<div></div>);
		}
  }
}
