class Receipt extends React.Component {
constructor(props) {
    super(props);
    this.state = {
    	couponInput:'',
		error_messages:{},
        success_messages:{},
        subtotal:"",

	};
    this.callPaymentApi=this.callPaymentApi.bind(this);
    this.handleClickCouponButton=this.handleClickCouponButton.bind(this);
	this.handleCouponInputChange=this.handleCouponInputChange.bind(this);
}
componentWillReceiveProps(nextProps){
	this.setState({subtotal:nextProps.subtotal});
	if(this.props.receiptWhereFieldValues['addressLat'] !== nextProps.receiptWhereFieldValues['addressLat'])
	{

    	$('input#addressLat').val(nextProps.receiptWhereFieldValues['addressLat']);
		$('input#addressLng').val(nextProps.receiptWhereFieldValues['addressLng']);

	    finalMap();
	}

}
callPaymentApi(){
	let time=this.props.receiptWhereFieldValues['dateSelected']+  " ساعت " +this.props.receiptWhereFieldValues['timeSelected'];
	let url=this.props.link+'/pay?email='+this.props.receiptPackageFieldValues['emailAddress']+
	"&mobile_number="+this.props.receiptPackageFieldValues['mobileNumber']+
	"&amount="+this.state.subtotal+
	"&project_id="+this.props.project_slug+
	"&description=123";
    window.location = url;
}
handleCouponInputChange(event){
    	this.setState({couponInput: event.target.value});
}
handleClickCouponButton(){
    	//add empty coupon input validation

    	let error_message = {};
    	let success_message = {};
    	error_message["coupon"]="";
    	success_message["coupon"]="";
    	this.setState({error_messages: error_message});
    	this.setState({success_messages: success_message});

    	let body="coupon[code]="+this.state.couponInput+"&project_slug="+this.props.project_slug;
        let url=this.props.link+'/api/v1/check_coupon';
        fetch(url, {method:'post',
            body: body,
            headers: { "Content-Type": "application/x-www-form-urlencoded","Accept":"application/json" ,"Authorization":this.props.token }})
            .then((response)=>{
            	response.json().then((object) =>{

            		if (object.response === "error") {

                		error_message["coupon"] = object.message;
                		this.setState({error_messages: error_message});

            		}
	            	else if(object.response === "ok"){

                		success_message["coupon"] = object.message;
                		this.setState({success_messages: success_message});
                		this.setState({subtotal:object.discounted_price});
	            	}

				})



     //       	console.log("coupon errors:"+this.state.error_messages["coupon"]);
            })
            .catch(function(e){console.log(e)});


}
render () {
	const persianDigits = "۰۱۲۳۴۵۶۷۸۹";
    const persianMap = persianDigits.split("");
    let isFull = this.props.receiptPackageFieldValues['is_full'];
    let packageDigitals =this.props.receiptPackageFieldValues['digitals'];
    return (
		<section id="main">
			<div className="container">
				<div className="main">
					<div className="wrapper">
						<div className="row">
							<div className="col-sm-6" id="final-details">
								<h3>اطلاعات نهایی</h3>
								<div className="detail-row">
									<span><img src={(this.props.link)+"/img/email.png"} alt="" /></span>
									<p>
										{(this.props.receiptPackageFieldValues['firstName'])+" "+
										(this.props.receiptPackageFieldValues['lastName'])+" - "+
										(this.props.receiptPackageFieldValues['emailAddress'])}
									</p>
								</div>
								<div className="detail-row">
									<span><img src={(this.props.link)+"/img/mobile.png"} alt=""/></span>
									<p>
									{this.props.receiptPackageFieldValues['mobileNumber']}
									</p>
								</div>
								<div className="detail-row">
									<span><img src={(this.props.link)+"/img/location.png"} alt=""/></span>
									<p>
										{this.props.receiptWhereFieldValues['addressDetail']}
									</p>
								</div>
								<div className="detail-row">
									<span><img src={(this.props.link)+"/img/date.png"} alt="" /></span>
									<p>
										{(this.props.receiptWhereFieldValues['dateSelected'])+  " ساعت " +(this.props.receiptWhereFieldValues['timeSelected'])}
									</p>
								</div>
								<div className="detail-row">
									<span><img src={(this.props.link)+"/img/package.png"} alt="" /></span>
									<p> {"پکیج: "+
										(this.props.receiptPackageFieldValues['title'])
										+" - "+
										(this.props.receiptPackageFieldValues['duration'])
										+" - "+
										((isFull==true)?'همه فریم ها':(packageDigitals)+" فریم دانلود")}

									</p>
								</div>
								<div className="detail-row">
									<span><img src={(this.props.link)+"/img/price.png"} alt=""/></span>
									<p>
										{"مبلغ: "+
										this.state.subtotal.toString().replace(/\d/g, function (m) {
            								return persianMap[parseInt(m)];
        								})+" تومان "}
									</p>
								</div>
								<div className="detail-row">
									<span><img src={(this.props.link)+"/img/photographer.png"} alt=""/></span>
									<p>
										{"عکاس: "+
										(this.props.receiptPhotographersFieldValues['firstName'])
										+" "+
										(this.props.receiptPhotographersFieldValues['lastName'])}
									</p>
								</div>
								<br />
								<div className="detail-row">
								</div>
							</div>
							<div className="col-sm-6">
								<input type="hidden" id="addressLat" value={this.props.receiptWhereFieldValues['addressLat']}/>
								<input type="hidden" id="addressLng" value={this.props.receiptWhereFieldValues['addressLng']}/>
								<div id="finalMap" style={{width: '100%', height: '400px'}}></div>
							</div>

						</div>{/*<!-- /.row -->*/}
						<hr />
						<figure id="coupon">
	                        <h3>
				              کد تخفیف:
				            </h3>

	                        <div className="input-box">
	                            <input id="coupon_input" name="coupon" type="text" placeholder="کوپن تخفیف" value={this.state.couponInput} onChange={this.handleCouponInputChange}/>
	                            <button id="coupon_submit_button" className="btn-blue" onClick={this.handleClickCouponButton}>ثبت</button>
	                        </div>
	                        <div id="coupon-result">
          						<h4 style={{color: 'red'}}>{this.state.error_messages["coupon"]}</h4>
	                            <h4 style={{color: 'green'}}>{this.state.success_messages["coupon"]}</h4>
				            </div>

	                    </figure>
	                    <hr />
						<div className="row">
							<div className="btn-wrap text-center">

								<button className="btn btn-blue complete" onClick={this.callPaymentApi}>
								ثبت و پرداخت

								</button>

							</div>
							<div className="col-md-12">
								<br />

							</div>
						</div>
					</div>{/*<!-- /.wrapper -->*/}
				</div>{/*<!-- /.main -->*/}
			</div>{/* /.container -->*/}
			<footer id="footer">
				<div className="container">
					<div className="wrap">
						<a className="btn btn-gray" onClick={this.props.previousStep} >بازگشت</a>
						<button type="submit" id = "submit_page_form" className="btn btn-blue" onClick={this.callPaymentApi}>پرداخت</button>
					</div>
				</div>
			</footer>
		</section>
    );
  }
}
