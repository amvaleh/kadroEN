class DatePickerTab extends React.Component {
	constructor() {
			super();
			this.state = {
				dateSelected:'',
				error_messages:{},
				availableHours:[],
				longitudeSelected:'',
				lattitudeSelected:'',
				locationSelected:'',
                isMapChanged:true,
			};

			this.callAvailableHoursApi=this.callAvailableHoursApi.bind(this);
			
	}

	componentDidMount(){
        

		let figure=$('#time-picker').find('figure');
		$( "#date_field" ).on("change", (changeEvt)=> {			
			this.setState({dateSelected:changeEvt.target.value})				
			this.props.isTimeSelected(false);
			figure.find('.times ul li').removeClass('selected');
			this.callAvailableHoursApi();
            
		});
	}
	componentWillReceiveProps(nextProps){
        if(nextProps.isMapChanged!==this.props.isMapChanged)
        {
            //hide time when map is changed before the isMapChange state become false
            $('#time-picker').addClass('hidden');
            $('#noHoursSpan').css('display', 'none');
            this.props.isTimeSelected(false);
            //console.log("isMapChanged state changed to: "+nextProps.isMapChanged);
            this.setState({'isMapChanged':nextProps.isMapChanged});
            
        }
        if(nextProps.longitudeSelected!==this.props.longitudeSelected || nextProps.lattitudeSelected!==this.props.lattitudeSelected )        
        {
            //////////when map is changed or selected
            this.setState({'longitudeSelected':nextProps.longitudeSelected});
            this.setState({'lattitudeSelected':nextProps.lattitudeSelected});
            this.setState({'locationSelected':nextProps.locationSelected});
            
            //////////when map is selected or changed scroll smoothly to calendar
            var target = $('#calendar');
            if( target.length ) {
              $('html, body').stop().animate({
                  scrollTop: target.offset().top
              }, 1000);
            }

            
            
        }
        if(nextProps.shootTypeSelectedId!==this.props.shootTypeSelectedId || nextProps.selectedServicePackageId!==this.props.selectedServicePackageId)
        {
            //////////hide time when shoot type or package id are changed
            $('#time-picker').addClass('hidden');
            $('#noHoursSpan').css('display', 'none');
            this.props.isTimeSelected(false);
        }
        
	  	
    }
    
	callAvailableHoursApi(){
		let available_hours=[];
		let error_messages = {};
		let body="free_time[date]="+this.state.dateSelected+"&free_time[shoot_type]="+this.props.shootTypeSelectedId+"&free_time[package_id]="+this.props.selectedServicePackageId+"&project_slug="+this.props.project_slug;
		let url=this.props.link+'/api/v1/available_hours';
		return fetch(url, {method:'post',
            body: body,
            headers: { "Content-Type": "application/x-www-form-urlencoded","Accept":"application/json" ,"Authorization":this.props.token }})
            .then((response)=>{
            	if (parseInt(response.status) != 202) {
            		
            		response.json().then((object) =>{
            			console.log("response error:"+object);
                		error_messages["available_hours_failure"] = object.messages;
                		this.setState({error_messages: error_messages});               		
    				});
            	}
                else{
                	response.json().then((object) =>{
      
                		if(object['response']=='nok')
                        {
                            $('#time-picker').addClass('hidden');
                            $('#noHoursSpan').css('display', 'block');                           
                            error_messages["available_hours_failure"] = "هیچ ساعت خالی برای این روز با شرایط انتخابی تان پیدا نشد";
                            this.setState({error_messages: error_messages}); 
                        }
                		else{
                			$('#time-picker').removeClass('hidden');
                			$('#noHoursSpan').css('display', 'none');
                			object["result"].map((item) =>{
      
                                available_hours.push(item);
                            });

                		}
	                	this.setState({availableHours: available_hours});	
                         		
    				});
                    
                }
     
            	
            	
            })
            .catch(function(e){console.log(e)});
	}	
  render () {
    
    if(this.state.isMapChanged)
    {
        
        return(
            <div id="calendar" className="wrapper calendar">
            </div>
        );
    }
    else{

        datePicker();//////////finaly show date span when map is initialized
        return (
                
    		  <div id="calendar" className="wrapper calendar">
    				<div className="row">
    					<div className="col-sm-6">
    						<span id="date-picker" > </span>
    					</div>
    					<div id="time-pick" className="col-sm-6">
    					<span id="noHoursSpan" style={{color: "red" , display: "none"}}>{this.state.error_messages["available_hours_failure"]}</span>
    						<div id="time-picker" className="hidden">
    							<header className="gdate"></header>
    							<figure className="row row-m0">
    								<AvailableHoursTab 
                                    availableHours={this.state.availableHours} 
                                    isTimeSelected={this.props.isTimeSelected} 
                                    dateTimeSelected={this.props.dateTimeSelected} 
                                    dateSelected={this.state.dateSelected}
                                    persianDateTimeData_callBack={this.props.persianDateTimeData_callBack}
                                     />
                                    
    							</figure>
    						</div>
    					</div>
    				</div>
    				
    			</div>
        );
    }
  }
}


