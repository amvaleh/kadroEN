class WhereAndWhen extends React.Component {
	
	constructor() {
		super();
		this.state = {			
			addressDetail:'',
			dateTimeSelected:'',
			error_messages:{},
			isTimeSelected:false,
			lattitudeSelected:'',
			longitudeSelected:'',
			locationSelected:'',
			dateLattitudeSelected:'',
			dateLongitudeSelected:'',
			dateLocationSelected:'',
			persianDateTimeData:{},
			isMapSelected:false,
			isMapChanged:false,
			showAddressDetail:false,
		};
		this.handleSubmitButton=this.handleSubmitButton.bind(this);
		this.handleAddressDetailChange=this.handleAddressDetailChange.bind(this);
		this.callAvailablePhotographerApi=this.callAvailablePhotographerApi.bind(this);
		this.callSubmitAddressApi=this.callSubmitAddressApi.bind(this);

	}
	handleSubmitButton(){
		if(!this.state.isTimeSelected)
		{
			$('#address-detail').parsley().validate();
			if(!$('#address-detail').parsley().isValid())
			{
				return;
			}
			this.callSubmitAddressApi();
			this.setState({dateLattitudeSelected:this.state.lattitudeSelected});
			this.setState({dateLongitudeSelected:this.state.longitudeSelected});
			this.setState({dateLocationSelected:this.state.locationSelected});
			this.setState({isMapSelected:false});
			this.setState({isMapChanged:false});
			
		}
		else {
			this.setState({isMapSelected:true});
			var data = {
				dateSelected:this.state.persianDateTimeData.dateSelected,
				timeSelected:this.state.persianDateTimeData.timeSelected,
				addressLng: this.state.longitudeSelected,
				addressLat: this.state.lattitudeSelected,
				addressInput: this.state.locationSelected,
				addressDetail: this.state.addressDetail,
		    }
		    this.props.dateTimeSelected(this.state.dateTimeSelected);
	    	this.props.receiptWhereFieldValues(data);
			this.callAvailablePhotographerApi();
			this.props.nextStep();
		}
	}
	handleAddressDetailChange(event){
		this.setState({addressDetail: event.target.value})
		this.setState({isTimeSelected:false});//for checking submit button to validate address detail
	  	this.setState({isMapSelected:true});//submit button enabled
	  	this.setState({isMapChanged:true});//calendar removed

	}
	

	componentDidMount(){
    	myMap();  
    	$("#latt").on("change", (changeEvt)=> {
    		
		  this.setState({lattitudeSelected:changeEvt.target.value},()=>{

		  	this.setState({isTimeSelected:false});//for checking submit button to validate address detail
		  	this.setState({isMapSelected:true});//submit button enabled
		  	this.setState({isMapChanged:true});//calendar removed
		  	this.setState({showAddressDetail:true});
		  });
		});
		$("#long").on("change", (changeEvt)=> {
			
		  this.setState({longitudeSelected:changeEvt.target.value},()=>{
		  	this.setState({isTimeSelected:false});//for checking submit button to validate address detail
		  	this.setState({isMapSelected:true});//submit button enabled
		  	this.setState({isMapChanged:true});//calendar removed
		  	this.setState({showAddressDetail:true});
		  });
		});
		$("#location").on("change", (changeEvt)=> {
	
		  this.setState({locationSelected:changeEvt.target.value},()=>{
		  	this.setState({isTimeSelected:false});//for checking submit button to validate address detail
		  	this.setState({isMapSelected:true});//submit button enabled
		  	this.setState({isMapChanged:true});//calendar removed
		  });
	
		});
	}
/* if you want to remove calendar and call submit address api again
	componentWillReceiveProps(nextProps){
		if(nextProps.shootTypeSelectedId!==this.props.shootTypeSelectedId || nextProps.selectedServicePackageId!==this.props.selectedServicePackageId)
        {
            
            this.setState({isTimeSelected:false});//for checking submit button to validate address detail and
            //call submit address api again
		  	this.setState({isMapSelected:true});//submit button enabled
		  	this.setState({isMapChanged:true});//calendar removed
        }
	}
*/
	callSubmitAddressApi(){
		let error_messages={};
		let body="address[longtitude]="+this.state.longitudeSelected+"&address[lattitude]="+this.state.lattitudeSelected+"&address[input]="+this.state.locationSelected+"&address[detail]="+this.state.addressDetail+"&project_slug="+this.props.project_slug;
        let url=this.props.link+'/api/v1/submit_address';
        return fetch(url, {method:'post',
            body: body,
            headers: { "Content-Type": "application/x-www-form-urlencoded","Accept":"application/json" ,"Authorization":this.props.token }})
            .then((response)=>{

            	if (parseInt(response.status) !== 202) {
            		response.json().then((object) =>{
            			console.log("response error:"+object);
                		error_messages["submit_address"] = object.messages;
                		this.setState({error_messages: error_messages});               		
    				});
            	}
                else{
                	response.json().then((object) =>{

                         		
    				});
                    
                }
     
            	
            	
            })
            .catch(function(e){console.log(e)});
	}

	callAvailablePhotographerApi(){
		let available_photographers=[];
		let photographer_photos=[];
		let photographers_photos_map={};
		let error_messages = {};
		let body="photographer[date]="+this.state.dateTimeSelected+"&project_slug="+this.props.project_slug;
		
		let url=this.props.link+'/api/v1/available_photographer';
		return fetch(url, {method:'post',
            body: body,
            headers: { "Content-Type": "application/x-www-form-urlencoded" }})
            .then((response)=>{
            	
            	if (parseInt(response.status) != 202) {
            		response.json().then((object) =>{
            			console.log("response error:"+object);
                		error_messages["available_photographer_failure"] = object.messages;
                		this.setState({error_messages: error_messages});               		
    				});
    			
            	}
                else{
                	
                	response.json().then((object) =>{
                
                		if(object.length==0)
                		{
                			console.log("no available photographers:");
                			error_messages["available_photographer_failure"] = "هیچ عکاس با شرایط انتخابی تان پیدا نشد";
                			this.setState({error_messages: error_messages}); 
                			
                		}
                		else{
                			object.map((item) =>{
	                			
	            				available_photographers.push(item);
	            				
								let url=this.props.link+'/api/v1/photographers_photos?photographer_id='+item.id+"&shoot_type_id="+this.props.shootTypeSelectedId;
								
								fetch(url, {method:'get',
						            })
						            .then((response)=>{
						            	
						            	if (parseInt(response.status) != 202) {
						            		
						            		response.json().then((object) =>{
						            			console.log("response error:"+object);
						              		
						    				});
						    
						            	}
						                else{
						                	
						                	response.json().then((object) =>{
						                		
							                		if(object.length==0)
							                		{              			
							                			console.log("no photos:");	
							                		}
							                		else{
							    						photographer_photos=[];
							                			object['photos'][0].map((item) =>{
								                			

								            				photographer_photos.push(item);
								            			});
								            			
								            			photographers_photos_map[item.id]=photographer_photos;
							                			
						                			}
						                			
						                			let keys = Object.keys(photographers_photos_map);
						                			
						                			if(keys.length==available_photographers.length)
						                			{
						                				
						                				this.props.photographersPhotos(photographers_photos_map);
						                			}
													
						                		});
						                		
						                	}	
					                		
							                		
						                         		
									})
						            .catch(function(e){console.log(e)});
	
	            			});

                			this.props.availablePhotographers(available_photographers);
                			
                		}
	                		
                         		
    				});
                    
                }
     
            	
            	
            })
            .catch(function(e){console.log(e)});
	}
	render () {
		return (
			<React.Fragment>
			  	<div className="container">
			    	<div className="main">
			      		<div className="tracker">
					        <div className="process-tabs-line w-hidden-tiny">
								<span className="step-line step-line-package active" style={{width: '33.3333%', right: '0%'}}></span>
								<span className="step-line step-line-datetime " style={{width: '33.3333%', right: '33.3333%'}}></span>
								<span className="step-line step-line-details" style={{width: '33.3333%', right: '66.6667%'}}></span>
					        </div>

			        		<div className="process-tab-button tracker-circle selected" style={{right: '0%'}}>
			          			<div className="tracker-text">
			            		پکیج
			          			</div>
			        		</div>
					        <div className="process-tab-button tracker-circle selected" style={{right: '33.3333%'}}>
					          <div className="tracker-text">
					            کی و کجا؟
					          </div>
					        </div>
					        <div className="process-tab-button tracker-circle" style={{right: '66.6667%'}}>
                                <div className="tracker-text">
                                    عکاس
                                </div>
                        	</div>
                            <div className="process-tab-button tracker-circle" style={{right: '100%'}}>
                                <div className="tracker-text">
                                    جزئیات
                                </div>
                            </div>
			      		</div>
      					<div className="wrapper">
					        <div className="row">
								<div className="col-sm-6">
									
									<input type="hidden" name="date" id="date_field" onChange={this.DateChange} value=''/>
						            <input type="hidden" name="time" id="time" value=''/>
						            <input type="text" id="latt" name="latitude" style={{display:'none'}} value=''/>
						            <input type="text" id="long" name="longitude" style={{display:'none'}} value=''/>
									
						            <div className="form-group">
										<label for="location">
										منطقه شما
										</label>
										<input type="text" name="address" className="form-control" id="location" placeholder="نام منطقه خود را به فارسی وارد کنید:" autocomplete="on" />
									</div>
						            
									<div className="form-group" style={{display: (!this.state.showAddressDetail)?'none':''}}>
										<label for="address-detail">جزئیات آدرس</label>
										<textarea 
										className="form-control"
										name="address-detail" 
										id="address-detail" 
										rows="7" 
										required 
										placeholder="جزئیات آدرس برای آمدن عکاس (مثال: بیا پلاک ۱۰، طبقه دوم، واحد ۳۰)" 
										onChange={this.handleAddressDetailChange}
										data-parsley-trigger="keyup"
										
										></textarea>
									</div>
									
									
								</div>
								<div className="col-sm-6">
									<div id="map" style={{width: '100%', height: '400px', position: 'relative', overflow: 'hidden'}}></div>
      							</div>
    						</div>
  						</div>
      					<br />
						<DatePickerTab 
						isTimeSelected={(id) => this.setState({isTimeSelected:id})} 
						token={this.props.token} 
						project_slug={this.props.project_slug} 
						shootTypeSelectedId={this.props.shootTypeSelectedId}
						lattitudeSelected={this.state.dateLattitudeSelected}
						longitudeSelected={this.state.dateLongitudeSelected}
						locationSelected={this.state.dateLocationSelected}
						dateTimeSelected={(id) => this.setState({dateTimeSelected:id})} 
						selectedServicePackageId={this.props.selectedServicePackageId}
						persianDateTimeData_callBack={(id) => this.setState({persianDateTimeData:id})} 
						isMapChanged={this.state.isMapChanged}
						link={this.props.link}
						/>
						<span style={{color: 'red'}}>{this.state.error_messages["available_photographer_failure"]}</span>
					</div>
				</div>
	  			<footer id="footer">
	                <div className="container">
	                    <div className="wrap">
	                        <a className="btn btn-gray" onClick={this.props.previousStep} >بازگشت</a>
	                        <button type="submit" id="submit_page_form" className="btn btn-blue" onClick={this.handleSubmitButton} disabled={(!this.state.isTimeSelected && !this.state.isMapSelected)} >ذخیره و ادامه
	                        </button>
	                    </div>
	                </div>
            	</footer>
			</React.Fragment>
		);
	}
}


